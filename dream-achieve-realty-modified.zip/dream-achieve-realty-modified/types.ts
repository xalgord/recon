
export interface Testimonial {
  id: number;
  name: string;
  title: string;
  quote: string;
  avatar: string;
}

// FIX: Define and export the Property interface.
export interface Property {
  id: number;
  address: string;
  city: string;
  price: number;
  image: string;
  type: 'For Sale' | 'For Rent';
  beds: number;
  baths: number;
  sqft: number;
}
