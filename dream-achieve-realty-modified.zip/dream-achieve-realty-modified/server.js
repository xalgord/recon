import 'dotenv/config';
import express from 'express';
import nodemailer from 'nodemailer';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import rateLimit from 'express-rate-limit';

const app = express();
const PORT = process.env.PORT || 3001;

// ES Module equivalent of __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middleware
// Use CORS for local development to allow requests from vite dev server
if (process.env.NODE_ENV !== 'production') {
    app.use(cors({ origin: 'http://localhost:5173' })); // Adjust to your Vite dev server port
}
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting to prevent spam
const emailRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 3, // Limit each IP to 3 requests per windowMs
  message: { success: false, message: 'Too many requests. Please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Server is running' });
});

// Create reusable transporter (create once, reuse for all emails)
const smtpPort = parseInt(process.env.SMTP_PORT || '465', 10);
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: smtpPort,
  secure: smtpPort === 465, // true for 465 (SSL), false for other ports (TLS)
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
  tls: {
    rejectUnauthorized: true
  },
  pool: true, // Use connection pooling for better performance
  maxConnections: 1,
  maxMessages: 3,
});

// API endpoint for sending emails
app.post('/api/send-email', emailRateLimit, async (req, res) => {
  const { name, email, phone, subject, message } = req.body;

  // Validation - check required fields
  if (!name || !email || !phone || !subject || !message) {
    return res.status(400).json({ success: false, message: 'All required fields are missing. Please fill in name, email, phone, subject, and message.' });
  }

  // Email format validation - only alphanumeric, @, and . allowed (no special characters)
  const emailRegex = /^[a-zA-Z0-9]+([a-zA-Z0-9._]*[a-zA-Z0-9])?@[a-zA-Z0-9]+([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ success: false, message: 'Invalid email format. Only letters, numbers, @, and . are allowed.' });
  }

  // Phone number validation - accepts: +918837504247, 08837504247, 1234567890, etc.
  // Only digits and optional + at the start (no special characters)
  const phoneRegex = /^(\+?[0-9]{10,15}|0[0-9]{9,14})$/;
  if (!phoneRegex.test(phone)) {
    return res.status(400).json({ success: false, message: 'Invalid phone number format. Only digits and optional + at the start are allowed (e.g., +918837504247 or 08837504247).' });
  }
  
  // Additional length check for phone (10-15 digits after removing +)
  const cleanPhone = phone.replace(/\+/g, '');
  if (cleanPhone.length < 10 || cleanPhone.length > 15) {
    return res.status(400).json({ success: false, message: 'Phone number must be between 10 and 15 digits.' });
  }

  // Basic spam detection - check for common spam patterns
  const spamPatterns = [
    /(http|https|www\.)/i, // URLs in message
    /(viagra|cialis|casino|poker|loan|mortgage)/i, // Common spam keywords
  ];
  
  const messageLower = message.toLowerCase();
  const subjectLower = subject.toLowerCase();
  
  // Allow URLs and keywords but log for review (you can make this stricter)
  // For now, we'll just validate length
  if (message.length < 10) {
    return res.status(400).json({ success: false, message: 'Message is too short.' });
  }
  
  if (message.length > 5000) {
    return res.status(400).json({ success: false, message: 'Message is too long.' });
  }

  // Email to receiver (notification)
  const notificationEmail = {
    from: `"Dream Achieve Realty" <${process.env.SMTP_USER}>`,
    to: process.env.SMTP_RECEIVER_EMAIL, // The email address where you want to receive messages
    replyTo: email,
    subject: `New Contact Form Submission: ${subject}`,
    html: `
      <h2>New Message from Dream Achieve Realty Contact Form</h2>
      <p><strong>Name:</strong> ${name}</p>
      <p><strong>Email:</strong> <a href="mailto:${email}">${email}</a></p>
      ${phone ? `<p><strong>Phone:</strong> <a href="tel:${phone}">${phone}</a></p>` : ''}
      <p><strong>Subject:</strong> ${subject}</p>
      <hr>
      <p><strong>Message:</strong></p>
      <p style="white-space: pre-wrap;">${message}</p>
    `,
  };

  // Confirmation email to sender
  const confirmationEmail = {
    from: `"Dream Achieve Realty" <${process.env.SMTP_USER}>`,
    to: email, // Send confirmation to the person who submitted the form
    subject: `Thank You for Contacting Dream Achieve Realty - ${subject}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #1e3a8a;">Thank You for Contacting Us, ${name}!</h2>
        <p>We have received your message and will get back to you within 24 hours.</p>
        
        <div style="background-color: #f1f5f9; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Your Message:</strong></p>
          <p style="margin: 5px 0; color: #666;">${subject}</p>
          <p style="margin: 10px 0 5px 0;"><strong>Details:</strong></p>
          <p style="margin: 5px 0; white-space: pre-wrap; color: #666;">${message}</p>
        </div>
        
        <p>If you have any urgent questions, please feel free to call us at <strong>(123) 456-7890</strong>.</p>
        
        <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 30px 0;">
        
        <p style="color: #666; font-size: 14px;">
          Best regards,<br>
          <strong>Dream Achieve Realty Team</strong><br>
          <a href="mailto:${process.env.SMTP_USER}" style="color: #1e3a8a;">${process.env.SMTP_USER}</a>
        </p>
      </div>
    `,
  };

  // Send response immediately (non-blocking)
  res.status(200).json({ success: true, message: 'Email sent successfully!' });

  // Send emails asynchronously in the background (don't wait for completion)
  (async () => {
    try {
      // Send notification email to receiver
      await transporter.sendMail(notificationEmail);
      console.log(`Notification email sent to ${process.env.SMTP_RECEIVER_EMAIL}`);
      
      // Send confirmation email to sender
      await transporter.sendMail(confirmationEmail);
      console.log(`Confirmation email sent to ${email}`);
    } catch (error) {
      console.error('Error sending email (background):', error);
      // Log error but don't affect user experience since response already sent
    }
  })();
});

// Serve the frontend in production
if (process.env.NODE_ENV === 'production') {
    // Serve static files from the 'dist' directory
    app.use(express.static(path.join(__dirname, 'dist')));

    // For any other request, serve the index.html file so client-side routing works
    app.get('*', (req, res) => {
        res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
} else {
    // Development mode - provide helpful message
    app.get('/', (req, res) => {
        res.send(`
            <html>
                <head><title>Dream Achieve Realty - Development Server</title></head>
                <body style="font-family: Arial, sans-serif; padding: 40px; text-align: center;">
                    <h1>🚀 Development Server Running</h1>
                    <p>This is the backend API server running on port ${PORT}</p>
                    <p><strong>To view the frontend:</strong></p>
                    <ol style="text-align: left; max-width: 600px; margin: 20px auto;">
                        <li>Open a new terminal</li>
                        <li>Run: <code>npm run dev</code></li>
                        <li>Visit: <a href="http://localhost:5173">http://localhost:5173</a></li>
                    </ol>
                    <p><strong>API Endpoints:</strong></p>
                    <ul style="text-align: left; max-width: 600px; margin: 20px auto;">
                        <li><code>POST /api/send-email</code> - Send contact form email</li>
                        <li><code>GET /api/health</code> - Server health check</li>
                    </ul>
                    <p style="margin-top: 40px; color: #666;">
                        <strong>For production:</strong> Run <code>npm run build</code> then <code>NODE_ENV=production npm run start:server</code>
                    </p>
                </body>
            </html>
        `);
    });
}

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
