# DNS Configuration Guide for dreamachieverealty.com

This guide will help you point your Hostinger domain `dreamachieverealty.com` to your Ubuntu server at `144.24.117.237`.

## Steps to Configure DNS in Hostinger

### 1. Log in to Hostinger
- Go to https://hpanel.hostinger.com/
- Log in with your Hostinger account credentials

### 2. Access DNS Management
- Navigate to **Domains** → Select `dreamachieverealty.com`
- Click on **DNS / Name Servers** or **DNS Zone Editor**

### 3. Delete Conflicting Records

**DELETE these records** (they point to Hostinger's hosting, not your server):

1. **ALIAS @** → `dreamachieverealty.com.cdn.hstgr.net` ❌ DELETE
2. **CNAME www** → `www.dreamachieverealty.com.cdn.hstgr.net` ❌ DELETE  
3. **A ftp** → `82.25.120.61` ❌ DELETE (optional, but not needed)

### 4. Keep These Records (Email & Security)

**KEEP all of these** - they're needed for email to work correctly:

✅ **Email Authentication (DKIM):**
- `CNAME hostingermail-a._domainkey` → `hostingermail-a.dkim.mail.hostinger.com`
- `CNAME hostingermail-b._domainkey` → `hostingermail-b.dkim.mail.hostinger.com`
- `CNAME hostingermail-c._domainkey` → `hostingermail-c.dkim.mail.hostinger.com`

✅ **Email Auto-Configuration:**
- `CNAME autodiscover` → `autodiscover.mail.hostinger.com`
- `CNAME autoconfig` → `autoconfig.mail.hostinger.com`

✅ **Email Security:**
- `TXT _dmarc` → `"v=DMARC1; p=none"`
- `TXT @` → `"v=spf1 include:_spf.mail.hostinger.com ~all"` (SPF record)

✅ **Email Receiving (MX):**
- `MX @` → `mx1.hostinger.com` (priority 5)
- `MX @` → `mx2.hostinger.com` (priority 10)

✅ **SSL Certificate Authorization (CAA):**
- All `CAA @` records (keep them all - they're fine)

### 5. Add New Records for Your Server

After deleting the conflicting records, **ADD these new records**:

#### A Record (Main Domain)
- **Type**: A
- **Name**: @ (or leave blank)
- **Value**: `144.24.117.237`
- **TTL**: 300 (or 3600)

#### A Record (WWW Subdomain)
- **Type**: A
- **Name**: www
- **Value**: `144.24.117.237`
- **TTL**: 300 (or 3600)

### 6. Save Changes
- Click **Save** or **Add Record** for each entry
- DNS changes typically propagate within 24-48 hours, but often take effect within a few minutes to a few hours

### 7. Verify DNS Propagation
You can verify that DNS is pointing correctly using these tools:
- https://www.whatsmydns.net/#A/dreamachieverealty.com
- https://dnschecker.org/#A/dreamachieverealty.com
- Command line: `nslookup dreamachieverealty.com` or `dig dreamachieverealty.com`

## Server Configuration on Ubuntu

After DNS is configured, ensure your Ubuntu server is ready:

### 1. Firewall Configuration
Make sure ports 80 (HTTP) and 443 (HTTPS) are open:
```bash
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw status
```

### 2. Web Server Setup
You'll need a web server (Nginx or Apache) to handle the domain:

#### Option A: Nginx (Recommended)
```bash
sudo apt update
sudo apt install nginx
```

Create a configuration file:
```bash
sudo nano /etc/nginx/sites-available/dreamachieverealty.com
```

Add this configuration:
```nginx
server {
    listen 80;
    server_name dreamachieverealty.com www.dreamachieverealty.com;

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/dreamachieverealty.com /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 3. SSL Certificate (HTTPS)
For production, set up SSL using Let's Encrypt:
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d dreamachieverealty.com -d www.dreamachieverealty.com
```

### 4. Process Manager (PM2)
To keep your Node.js server running:
```bash
sudo npm install -g pm2
cd /path/to/dream-achieve-realty
pm2 start server.js --name dream-achieve-realty
pm2 save
pm2 startup
```

## Testing

1. **Test DNS**: `ping dreamachieverealty.com` should resolve to `144.24.117.237`
2. **Test HTTP**: Visit `http://dreamachieverealty.com` in a browser
3. **Test HTTPS**: After SSL setup, visit `https://dreamachieverealty.com`
4. **Test Email**: Submit the contact form to verify SMTP is working

## Troubleshooting

- **DNS not resolving**: Wait 24-48 hours for full propagation, or check DNS records are saved correctly
- **Connection refused**: Check firewall rules and ensure the server is running
- **502 Bad Gateway**: Ensure your Node.js server is running on port 3001
- **Email not sending**: Check SMTP credentials in `.env` file and verify Hostinger email account is active

