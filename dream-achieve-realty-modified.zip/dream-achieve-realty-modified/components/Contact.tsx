import React, { useState } from 'react';

// New, consistent icons
const MapPinIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
    </svg>
);

const PhoneIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
    </svg>
);

const MailIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
    </svg>
);


const SocialIcon: React.FC<{ href: string; children: React.ReactNode }> = ({ href, children }) => (
    <a href={href} target="_blank" rel="noopener noreferrer" className="text-slate-300 hover:text-brand-yellow transition-colors duration-300">
        {children}
    </a>
);


const Contact: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', subject: '', message: '', website: '' });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [formStartTime] = useState(Date.now());

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    let filteredValue = value;
    
    // Restrict special characters in email (only alphanumeric, @, and .)
    if (name === 'email') {
      filteredValue = value.replace(/[^a-zA-Z0-9@.]/g, '');
    }
    
    // Restrict special characters in phone (only digits and +)
    if (name === 'phone') {
      // Allow only digits and + at the start
      if (value.startsWith('+')) {
        filteredValue = '+' + value.slice(1).replace(/[^0-9]/g, '');
      } else {
        filteredValue = value.replace(/[^0-9]/g, '');
      }
    }
    
    setFormData(prev => ({ ...prev, [name]: filteredValue }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // Honeypot check - if website field is filled, it's a bot
    if (formData.website) {
      // Silently fail - don't let bots know they were caught
      return;
    }
    
    // Minimum time check - forms filled too quickly are likely spam
    const timeSpent = Date.now() - formStartTime;
    if (timeSpent < 3000) { // Less than 3 seconds
      setStatus('error');
      setTimeout(() => { if (status === 'error') setStatus('idle'); }, 5000);
      return;
    }
    
    // Validation - check required fields
    if (!formData.name || !formData.email || !formData.phone || !formData.subject || !formData.message) {
      setStatus('error');
      setTimeout(() => { if (status === 'error') setStatus('idle'); }, 5000);
      return;
    }
    
    // Email validation - only alphanumeric, @, and . allowed
    const emailRegex = /^[a-zA-Z0-9]+([a-zA-Z0-9._]*[a-zA-Z0-9])?@[a-zA-Z0-9]+([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(formData.email)) {
      setStatus('error');
      setTimeout(() => { if (status === 'error') setStatus('idle'); }, 5000);
      return;
    }
    
    // Phone number validation - accepts: +918837504247, 08837504247, 1234567890, etc.
    // Only digits and optional + at the start
    const phoneRegex = /^(\+?[0-9]{10,15}|0[0-9]{9,14})$/;
    if (!phoneRegex.test(formData.phone)) {
      setStatus('error');
      setTimeout(() => { if (status === 'error') setStatus('idle'); }, 5000);
      return;
    }
    
    // Additional length check for phone (10-15 digits)
    const cleanPhone = formData.phone.replace(/\+/g, '');
    if (cleanPhone.length < 10 || cleanPhone.length > 15) {
      setStatus('error');
      setTimeout(() => { if (status === 'error') setStatus('idle'); }, 5000);
      return;
    }
    
    setStatus('submitting');
    try {
      const response = await fetch('/api/send-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          subject: formData.subject,
          message: formData.message,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Server error' }));
        throw new Error(errorData.message || 'Server error');
      }

      const result = await response.json();

      if (result.success) {
        setStatus('success');
        setFormData({ name: '', email: '', phone: '', subject: '', message: '', website: '' });
        setTimeout(() => setStatus('idle'), 5000);
      } else {
        setStatus('error');
        setTimeout(() => { if (status === 'error') setStatus('idle'); }, 5000);
      }
    } catch (error) {
      console.error('Submission failed:', error);
      setStatus('error');
      setTimeout(() => { if (status === 'error') setStatus('idle'); }, 5000);
    }
  };

  return (
    <section id="contact" className="py-24 bg-brand-gray">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-brand-blue-dark font-serif">Get In Touch</h2>
          <p className="mt-4 text-lg text-slate-500 max-w-2xl mx-auto">Have a question or want to schedule a viewing? We're here to help.</p>
        </div>
        <div className="max-w-6xl mx-auto bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2">
                <div className="bg-brand-blue-dark text-white p-8 md:p-12 flex flex-col justify-center">
                    <h3 className="text-3xl font-bold mb-4 text-brand-yellow font-serif">Contact Information</h3>
                    <p className="text-slate-300 mb-8 leading-relaxed">
                        Fill up the form and our team will get back to you within 24 hours. Alternatively, you can reach us through the channels below.
                    </p>
                    <ul className="space-y-6">
                        <li className="flex items-start">
                            <MapPinIcon className="w-7 h-7 flex-shrink-0 mt-1 mr-4 text-brand-yellow" />
                            <div>
                                <p className="font-semibold text-lg">Our Office</p>
                                <p className="text-slate-300">Gmada Aerocity,<br />Matran, 140306, Mohali, Punjab, India</p>
                            </div>
                        </li>
                        <li className="flex items-start">
                            <PhoneIcon className="w-7 h-7 flex-shrink-0 mt-1 mr-4 text-brand-yellow" />
                            <div>
                                <p className="font-semibold text-lg">Phone</p>
                                <a href="tel:+919603261000" className="text-slate-300 hover:text-white transition-colors">+91 96032-61000</a>
                            </div>
                        </li>
                        <li className="flex items-start">
                            <MailIcon className="w-7 h-7 flex-shrink-0 mt-1 mr-4 text-brand-yellow" />
                            <div>
                                <p className="font-semibold text-lg">Email</p>
                                <a href="mailto:info@dreamachieverealty.com" className="text-slate-300 hover:text-white transition-colors">info@dreamachieverealty.com</a>
                            </div>
                        </li>
                    </ul>
                </div>

                <div className="p-8 md:p-12">
                    {status === 'success' ? (
                         <div className="flex flex-col justify-center items-center text-center h-full">
                            <h3 className="text-2xl font-bold text-green-600 mb-2 font-serif">Message Sent!</h3>
                            <p className="text-slate-600">Thank you for contacting us. We'll be in touch shortly.</p>
                        </div>
                    ) : (
                        <form onSubmit={handleSubmit} noValidate className="h-full flex flex-col relative">
                            {/* Honeypot field - hidden from users but visible to bots */}
                            <div style={{ position: 'absolute', left: '-9999px', opacity: 0, pointerEvents: 'none' }}>
                                <label htmlFor="website">Website (leave blank)</label>
                                <input type="text" name="website" id="website" value={formData.website} onChange={handleChange} tabIndex={-1} autoComplete="off" />
                            </div>
                            <div className="space-y-6 flex-grow">
                                <div>
                                    <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1">Full Name <span className="text-red-500">*</span></label>
                                    <input type="text" name="name" id="name" required value={formData.name} onChange={handleChange} className="w-full px-4 py-3 bg-slate-100 rounded-lg border-transparent focus:ring-2 focus:ring-brand-yellow focus:border-brand-yellow outline-none transition" placeholder="John Doe" />
                                </div>
                                <div>
                                    <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">Email Address <span className="text-red-500">*</span></label>
                                    <input type="email" name="email" id="email" required value={formData.email} onChange={handleChange} className="w-full px-4 py-3 bg-slate-100 rounded-lg border-transparent focus:ring-2 focus:ring-brand-yellow focus:border-brand-yellow outline-none transition" placeholder="you@example.com" />
                                </div>
                                <div>
                                    <label htmlFor="phone" className="block text-sm font-medium text-slate-700 mb-1">Phone Number <span className="text-red-500">*</span></label>
                                    <input type="tel" name="phone" id="phone" required value={formData.phone} onChange={handleChange} className="w-full px-4 py-3 bg-slate-100 rounded-lg border-transparent focus:ring-2 focus:ring-brand-yellow focus:border-brand-yellow outline-none transition" placeholder="+1234567890 or 01234567890" />
                                    <p className="text-xs text-slate-500 mt-1">Format: +1234567890 or 01234567890 (digits only, + optional at start)</p>
                                </div>
                                <div>
                                     <label htmlFor="subject" className="block text-sm font-medium text-slate-700 mb-1">Subject <span className="text-red-500">*</span></label>
                                    <input type="text" name="subject" id="subject" required value={formData.subject} onChange={handleChange} className="w-full px-4 py-3 bg-slate-100 rounded-lg border-transparent focus:ring-2 focus:ring-brand-yellow focus:border-brand-yellow outline-none transition" placeholder="Question about a property" />
                                </div>
                                 <div>
                                     <label htmlFor="message" className="block text-sm font-medium text-slate-700 mb-1">Message <span className="text-red-500">*</span></label>
                                    <textarea name="message" id="message" rows={5} required value={formData.message} onChange={handleChange} className="w-full px-4 py-3 bg-slate-100 rounded-lg border-transparent focus:ring-2 focus:ring-brand-yellow focus:border-brand-yellow outline-none transition resize-none" placeholder="I'd like to know more about..."></textarea>
                                </div>
                            </div>
                            {status === 'error' && <p className="text-red-500 text-sm mt-4 text-center">Something went wrong. Please check your input and try again.</p>}
                             <div className="mt-8 text-left">
                                <button type="submit" disabled={status === 'submitting'} className="w-full md:w-auto inline-block px-12 py-4 bg-brand-blue text-white rounded-lg font-bold text-base hover:bg-brand-blue-dark transition-all duration-300 shadow-md hover:shadow-lg transform hover:-translate-y-0.5 disabled:bg-slate-400 disabled:cursor-not-allowed disabled:transform-none">
                                    {status === 'submitting' ? 'Sending...' : 'Send Message'}
                                </button>
                            </div>
                        </form>
                    )}
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;