import React from 'react';
// FIX: Import the 'Property' type.
import type { Testimonial, Property } from './types';

export const NAV_LINKS = [
  { href: '#services', label: 'Services' },
  { href: '#about', label: 'About Us' },
  { href: '#testimonials', label: 'Testimonials' },
  { href: '#contact', label: 'Contact' },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: 'Aarav Sharma',
    title: 'Commercial Client',
    quote: "Dream Achieve Realty's deep knowledge of the Mohali commercial market was invaluable. They helped us secure the perfect office space with incredible professionalism and efficiency.",
    avatar: 'https://picsum.photos/seed/avatar1/100/100',
  },
  {
    id: 2,
    name: 'Priya Kaur',
    title: 'Residential Homeowner',
    quote: "As a family, we were looking for a home, not just a house. Their team guided us through every step of finding our dream home in Tricity. Their local expertise is unmatched.",
    avatar: 'https://picsum.photos/seed/avatar2/100/100',
  },
  {
    id: 3,
    name: 'Vikram Singh Logistics',
    title: 'Industrial Partner',
    quote: "For our industrial and warehousing needs, Dream Achieve Realty were the ultimate professionals. They understood our specific requirements and found a location that was perfect for our operations.",
    avatar: 'https://picsum.photos/seed/avatar3/100/100',
  },
];

// FIX: Define and export the PROPERTIES constant with sample data.
export const PROPERTIES: Property[] = [
  {
    id: 1,
    address: '123 Modern Avenue',
    city: 'Sector 70, Mohali',
    price: 7500000,
    image: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?q=80&w=1974&auto=format&fit=crop',
    type: 'For Sale',
    beds: 3,
    baths: 2,
    sqft: 1800,
  },
  {
    id: 2,
    address: '456 Corporate Plaza',
    city: 'Industrial Area, Mohali',
    price: 45000,
    image: 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?q=80&w=2070&auto=format&fit=crop',
    type: 'For Rent',
    beds: 0,
    baths: 4,
    sqft: 5000,
  },
  {
    id: 3,
    address: '789 Skyline Heights',
    city: 'Sector 91, Mohali',
    price: 12500000,
    image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?q=80&w=2070&auto=format&fit=crop',
    type: 'For Sale',
    beds: 4,
    baths: 4,
    sqft: 3200,
  },
];

export const Logo: React.FC<{ className?: string }> = ({ className }) => (
    <div className={`flex items-center gap-3 ${className || ''}`}>
        <img 
            src="/logo.png" 
            alt="Dream Achieve Realty Logo" 
            className="h-14 w-auto rounded-lg object-contain"
            onError={(e) => {
                console.error('Logo image failed to load');
                e.currentTarget.style.display = 'none';
            }}
        />
        <div className="tracking-widest text-sm font-bold">
            <span className="text-[#1e3a8a]">DREAM ACHIEVE</span>
            <span className="text-[#facc15] ml-1">REALTY</span>
        </div>
    </div>
);