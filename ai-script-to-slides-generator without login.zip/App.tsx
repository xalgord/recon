import React, { useState, useCallback, useEffect, useMemo } from 'react';
import * as geminiService from './services/geminiService';
import * as openaiService from './services/openaiService';
import { Slide as SlideType, Theme, AppSettings } from './types';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Slide from './components/Slide';
import Loader from './components/Loader';
import ExportControls from './components/ExportControls';
import SettingsModal from './components/SettingsModal';
import ApiGuideModal from './components/ApiGuideModal';

const THEMES: Theme[] = [
    { 
        name: 'Neon Droid',
        backgroundColor: '#000000',
        accentColor: '#00FF99',
        textColor: '#FFFFFF',
        font: 'Inter, sans-serif',
        description: 'A dark, futuristic theme with neon green accents. Think cyberpunk and high-tech.'
    },
    { 
        name: 'Professional',
        backgroundColor: '#FFFFFF',
        accentColor: '#0A74DA',
        textColor: '#1F2937',
        font: 'Inter, sans-serif',
        description: 'A clean, modern, and corporate theme with a blue accent color. Professional and minimalist.'
    },
    {
        name: 'Sunset',
        backgroundColor: '#1E1B4B', // Indigo-900
        accentColor: '#F97316', // Orange-500
        textColor: '#E0E7FF', // Indigo-100
        font: "'Georgia', serif",
        description: 'A warm and creative theme with a dark indigo background and a vibrant orange accent. Evokes a sense of dusk or sunset.'
    },
    {
        name: 'Noir',
        backgroundColor: '#171717', // Neutral-900
        accentColor: '#FFFFFF',
        textColor: '#A3A3A3', // Neutral-400
        font: "'Times New Roman', serif",
        description: 'A dramatic, high-contrast black and white theme. Suggests mystery, elegance, and a cinematic feel.'
    }
];

const APP_SETTINGS_KEY = 'ai-slide-deck-settings';

const DEFAULT_SETTINGS: AppSettings = {
  defaultThemeName: 'Neon Droid',
  defaultNumSlides: 10,
  defaultRateLimitDelay: 10,
  defaultApiProvider: 'gemini',
  apiKeys: { gemini: [], openai: [] },
};

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const App: React.FC = () => {
  const [slides, setSlides] = useState<SlideType[]>([]);
  const [script, setScript] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isApiGuideModalOpen, setIsApiGuideModalOpen] = useState(false);

  const [appSettings, setAppSettings] = useState<AppSettings>(() => {
    try {
        const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
        if (storedSettings) {
            const parsed = JSON.parse(storedSettings);
            const apiKeys = {
                gemini: Array.isArray(parsed.apiKeys?.gemini) ? parsed.apiKeys.gemini : [],
                openai: Array.isArray(parsed.apiKeys?.openai) ? parsed.apiKeys.openai : [],
            };
            return { ...DEFAULT_SETTINGS, ...parsed, apiKeys };
        }
        return DEFAULT_SETTINGS;
    } catch (error) {
        console.error("Could not load settings from local storage", error);
        return DEFAULT_SETTINGS;
    }
  });
  
  const activeApiProvider = appSettings.defaultApiProvider;
  const service = activeApiProvider === 'gemini' ? geminiService : openaiService;

  const activeApiKeys = useMemo(() => {
    const userKeys = appSettings.apiKeys[activeApiProvider];
    if (userKeys && userKeys.length > 0) {
        return userKeys.filter(Boolean);
    }
    if (process.env.API_KEY) {
        return process.env.API_KEY.split(',').map(k => k.trim()).filter(Boolean);
    }
    return [];
  }, [appSettings.apiKeys, activeApiProvider]);


  useEffect(() => {
    try {
        localStorage.setItem(APP_SETTINGS_KEY, JSON.stringify(appSettings));
    } catch (error) {
        console.error("Could not save settings to local storage", error);
    }
  }, [appSettings]);

  const [numSlides, setNumSlides] = useState<number>(appSettings.defaultNumSlides);
  const [rateLimitDelay, setRateLimitDelay] = useState<number>(appSettings.defaultRateLimitDelay);
  const [themes] = useState<Theme[]>(THEMES);
  const [selectedTheme, setSelectedTheme] = useState<Theme>(() => themes.find(t => t.name === appSettings.defaultThemeName) || themes[0]);
  
  useEffect(() => {
    setNumSlides(appSettings.defaultNumSlides);
    setRateLimitDelay(Math.max(10, appSettings.defaultRateLimitDelay)); // Enforce min 10s
    setSelectedTheme(themes.find(t => t.name === appSettings.defaultThemeName) || themes[0]);
  }, [appSettings, themes]);

  const handleGenerateSlides = useCallback(async () => {
    if (!script || numSlides <= 0) {
      setError('Please provide a script and a valid number of slides.');
      return;
    }
    
    const isUsingDefaultKeys = appSettings.apiKeys[activeApiProvider].length === 0;
    if (numSlides > 8 && isUsingDefaultKeys && activeApiProvider === 'gemini') {
        setIsApiGuideModalOpen(true);
        return;
    }

    if (activeApiKeys.length === 0) {
      setError(`No ${activeApiProvider.toUpperCase()} API Key found. Please add an API key in the settings or configure a default key.`);
      return;
    }

    setIsLoading(true);
    setError(null);
    setSlides([]);
    
    try {
      setLoadingMessage('Crafting slide content...');
      // Use the first key for content generation as it's a single, larger request
      const slideContents = await service.generateSlidesFromScript(activeApiKeys[0], script, numSlides, selectedTheme.description);

      const initialSlides: SlideType[] = slideContents.map((content, index) => ({
        ...content,
        id: `slide-${index}-${Date.now()}`,
        imageUrl: null,
        backgroundColor: selectedTheme.backgroundColor,
        font: selectedTheme.font,
        accentColor: selectedTheme.accentColor,
      }));
      setSlides(initialSlides);

      setLoadingMessage('Generating stunning visuals...');
      
      const slidesToUpdate = [...initialSlides];
      let imageGenerationFailed = false;
      let currentKeyIndex = 0;

      for (let i = 0; i < slidesToUpdate.length; i++) {
        const slide = slidesToUpdate[i];
        if (slide.visualSuggestion.startsWith('IMAGE:') || slide.visualSuggestion.startsWith('ILLUSTRATION:')) {
            let success = false;
            let attempt = 1;

            while (!success) { // "Unlimited" retry loop for this slide
                const apiKeyForThisRequest = activeApiKeys[currentKeyIndex];
                try {
                    setLoadingMessage(`Generating visual for slide ${i + 1}... (Key ${currentKeyIndex + 1}/${activeApiKeys.length}, Attempt ${attempt})`);
                    const imageUrl = await service.generateImageForSlide(apiKeyForThisRequest, slide.visualSuggestion);
                    slidesToUpdate[i].imageUrl = imageUrl;
                    setSlides([...slidesToUpdate]);
                    success = true; // Breaks the while loop
                } catch (imageError) {
                    const isRateLimitError = imageError instanceof Error && (imageError.message.toLowerCase().includes('rate limit') || imageError.message.toLowerCase().includes('quota') || imageError.message.toLowerCase().includes('429'));

                    if (isRateLimitError) {
                        attempt++;
                        const cooldown = 60000; // 60-second global cooldown
                        setLoadingMessage(`Rate limit on Key ${currentKeyIndex + 1}. Pausing for ${cooldown / 1000}s...`);
                        await sleep(cooldown);
                        
                        // Rotate to the next key
                        const nextKeyIndex = (currentKeyIndex + 1) % activeApiKeys.length;
                        currentKeyIndex = nextKeyIndex;
                        setLoadingMessage(`Switched to Key ${currentKeyIndex + 1}. Retrying...`);
                        // The loop will continue with the new key
                    } else {
                        // This is a non-recoverable error
                        const finalErrorMsg = `Failed to generate image for slide ${i + 1} due to a persistent error: ${imageError instanceof Error ? imageError.message : 'Unknown error'}. Please check your API key's validity and permissions.`;
                        setError(finalErrorMsg);
                        console.error(finalErrorMsg, imageError);
                        imageGenerationFailed = true;
                        break; // Break the while loop
                    }
                }
            } // End of while(!success) loop

            if (imageGenerationFailed) {
                break; // Exit the main for-loop over slides
            }
        }
        
        // Apply the user-configured delay between successful image generations
        if (i < slidesToUpdate.length - 1 && rateLimitDelay > 0) {
            await sleep(rateLimitDelay * 1000);
        }
      }

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [script, numSlides, selectedTheme, rateLimitDelay, activeApiKeys, service, appSettings.apiKeys, activeApiProvider]);

  const handleSlideUpdate = (index: number, field: 'title' | 'content', value: string) => {
    setSlides(prevSlides => {
      const newSlides = [...prevSlides];
      if (newSlides[index]) {
        newSlides[index][field] = value;
      }
      return newSlides;
    });
  };

  return (
    <div className="bg-gray-900 min-h-screen text-white">
      {isLoading && <Loader message={loadingMessage} />}
      <Header onOpenSettings={() => setIsSettingsOpen(true)} />
      <SettingsModal 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={appSettings}
        onSave={setAppSettings}
        themes={themes}
      />
      <ApiGuideModal
        isOpen={isApiGuideModalOpen}
        onClose={() => setIsApiGuideModalOpen(false)}
        onGoToSettings={() => {
            setIsApiGuideModalOpen(false);
            setIsSettingsOpen(true);
        }}
       />
      <main>
        <Dashboard
          script={script}
          setScript={setScript}
          numSlides={numSlides}
          setNumSlides={setNumSlides}
          rateLimitDelay={rateLimitDelay}
          setRateLimitDelay={setRateLimitDelay}
          onSubmit={handleGenerateSlides}
          isLoading={isLoading}
          themes={themes}
          selectedTheme={selectedTheme}
          onSelectTheme={setSelectedTheme}
        />
        {error && (
          <div className="container mx-auto px-4 text-center my-4">
            <p className="bg-red-900/50 text-red-300 p-3 rounded-lg border border-red-700">{error}</p>
          </div>
        )}
        {slides.length > 0 && (
          <div className="container mx-auto px-4 pb-16 space-y-12">
            <div className='text-center space-y-4'>
                <h2 className="text-3xl font-bold text-white">Your Generated Slides</h2>
                <ExportControls themeName={selectedTheme.name} />
            </div>
            {slides.map((slide, index) => (
              <Slide
                key={slide.id}
                slide={slide}
                index={index}
                onUpdate={handleSlideUpdate}
                textColor={selectedTheme.textColor}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default App;