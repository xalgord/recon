import React from 'react';
import { XIcon } from './icons';

interface ApiGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGoToSettings: () => void;
}

const ApiGuideModal: React.FC<ApiGuideModalProps> = ({ isOpen, onClose, onGoToSettings }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center"
      onClick={onClose}
    >
      <div
        className="bg-gray-900 border border-gray-700 rounded-xl shadow-2xl w-full max-w-lg m-4 flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <div className="p-6 border-b border-gray-700 flex justify-between items-center">
          <h2 className="text-xl font-bold text-white">Add Your API Key for More Slides</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        <div className="p-6 space-y-6">
            <p className="text-gray-300">
                For generating more than 8 slides, we recommend adding your own free Google Gemini API key. This helps prevent rate-limiting and ensures a smooth experience.
            </p>

            <div>
                <h3 className="font-semibold text-white mb-2">How to get your API Key:</h3>
                <ol className="list-decimal list-inside space-y-2 text-gray-400">
                    <li>Go to <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-[#00FF99] underline">Google AI Studio</a>.</li>
                    <li>Click <span className="font-semibold text-gray-200">"Create API key in new project"</span>.</li>
                    <li>Copy the generated API key.</li>
                    <li>Come back here, go to Settings, and paste your key in the Gemini tab.</li>
                </ol>
            </div>
             <p className="text-sm text-gray-500">
                Google provides a generous free tier that is more than enough for personal use.
            </p>
        </div>
        <div className="p-4 bg-gray-900/50 border-t border-gray-700 flex justify-end items-center gap-4 rounded-b-xl">
             <button
                onClick={onClose}
                className="px-6 py-2 bg-gray-700 text-white font-bold rounded-lg hover:bg-gray-600 transition-colors"
              >
                Cancel
              </button>
             <button
                onClick={onGoToSettings}
                className="px-6 py-2 bg-[#00FF99] text-black font-bold rounded-lg hover:bg-opacity-80 transition-colors"
              >
                Go to Settings
              </button>
        </div>
      </div>
    </div>
  );
};

export default ApiGuideModal;