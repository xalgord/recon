import React, { useRef } from 'react';
import { Slide as SlideType } from '../types';
import { DownloadIcon } from './icons';

declare var html2canvas: any;

interface SlideProps {
  slide: SlideType;
  index: number;
  onUpdate: (index: number, field: 'title' | 'content', value: string) => void;
  textColor: string;
}

const EditableText: React.FC<{
  initialValue: string;
  onSave: (value: string) => void;
  className: string;
  placeholder: string;
}> = ({ initialValue, onSave, className, placeholder }) => {
    const elementRef = useRef<HTMLDivElement>(null);
    
    const handleBlur = () => {
        if (elementRef.current) {
            const text = elementRef.current.innerText;
            if (text.trim() === '') {
                onSave('');
            } else {
                onSave(text);
            }
        }
    };
    
    return (
        <div
          ref={elementRef}
          contentEditable
          suppressContentEditableWarning
          onBlur={handleBlur}
          className={`outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-[#00FF99] p-1 rounded-md transition-shadow ${className} empty:before:content-[attr(data-placeholder)] empty:before:text-gray-500 empty:before:pointer-events-none`}
          data-placeholder={placeholder}
          dangerouslySetInnerHTML={{ __html: initialValue.replace(/\n/g, '<br />') }}
        ></div>
    );
};

const Slide: React.FC<SlideProps> = ({ slide, index, onUpdate, textColor }) => {
  const handleDownloadPng = async () => {
    const slideElement = document.getElementById(`slide-container-${index}`);
    if (slideElement) {
        try {
            const canvas = await html2canvas(slideElement, { scale: 2 }); // Higher scale for better quality
            const imageURL = canvas.toDataURL('image/png');
            const link = document.createElement('a');
            link.href = imageURL;
            link.download = `slide-${index + 1}.png`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (error) {
            console.error('Failed to download slide as PNG:', error);
            // Optionally show an error to the user
        }
    }
  };

  const renderContent = () => {
    const title = (
      <EditableText 
        initialValue={slide.title}
        onSave={(value) => onUpdate(index, 'title', value)}
        className="text-2xl md:text-4xl font-bold"
        placeholder="Editable Title"
      />
    );

    const content = (
      <EditableText 
        initialValue={slide.content}
        onSave={(value) => onUpdate(index, 'content', value)}
        className="text-base md:text-lg mt-4 whitespace-pre-wrap"
        placeholder="Editable content..."
      />
    );
    
    const imageElement = slide.imageUrl ? <img src={slide.imageUrl} alt={slide.visualSuggestion} className="w-full h-full object-cover" /> : null;

    switch (slide.layout) {
      case 'TITLE_ONLY':
        return <div className="p-8 md:p-12 flex items-center justify-center text-center"><div style={{ color: slide.accentColor }}>{title}</div></div>;
      case 'TITLE_AND_CONTENT':
        return <div className="p-8 md:p-12 flex flex-col justify-center"><div style={{ color: slide.accentColor }}>{title}</div>{content}</div>;
      case 'IMAGE_LEFT_TEXT_RIGHT':
        return <div className="flex h-full">
            <div className="w-1/2 h-full bg-gray-800">{imageElement}</div>
            <div className="w-1/2 p-6 md:p-8 flex flex-col justify-center"><div style={{ color: slide.accentColor }}>{title}</div>{content}</div>
        </div>;
      case 'IMAGE_RIGHT_TEXT_LEFT':
        return <div className="flex h-full">
            <div className="w-1/2 p-6 md:p-8 flex flex-col justify-center"><div style={{ color: slide.accentColor }}>{title}</div>{content}</div>
            <div className="w-1/2 h-full bg-gray-800">{imageElement}</div>
        </div>;
      case 'FULL_BLEED_IMAGE':
        return <div className="relative h-full w-full">
            {imageElement}
            <div className="absolute inset-0 bg-black/50 p-8 md:p-12 flex flex-col justify-end">
                <div style={{ color: slide.accentColor }}>{title}</div>
                {content}
            </div>
        </div>;
      case 'BLANK':
        return null;
      default:
        return <div className="p-8 md:p-12"><div style={{ color: slide.accentColor }}>{title}</div>{content}</div>;
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto scroll-mt-4" id={`slide-${index}`}>
       <div 
        id={`slide-container-${index}`}
        className="group relative w-full aspect-video bg-black rounded-lg shadow-2xl overflow-hidden border border-gray-700">
        <div className="absolute inset-0" style={{ color: textColor, fontFamily: slide.font, backgroundColor: slide.backgroundColor }}>
          {renderContent()}
        </div>
        <button
            onClick={handleDownloadPng}
            className="absolute top-3 right-3 z-10 bg-black/50 p-2 rounded-full text-white/70 hover:text-white hover:bg-black/70 transition-all opacity-0 group-hover:opacity-100"
            aria-label="Download as PNG"
        >
            <DownloadIcon className="w-5 h-5" />
        </button>
      </div>
      <div className="text-center mt-2 text-sm text-gray-500">Slide {index + 1}</div>
    </div>
  );
};

export default Slide;