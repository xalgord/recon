export type SlideLayout = 
  | 'TITLE_ONLY' 
  | 'TITLE_AND_CONTENT' 
  | 'IMAGE_LEFT_TEXT_RIGHT' 
  | 'IMAGE_RIGHT_TEXT_LEFT'
  | 'FULL_BLEED_IMAGE'
  | 'IMAGE_OVERLAP_LEFT'
  | 'IMAGE_OVERLAP_RIGHT'
  | 'BLANK';

export interface Position {
  x: number;
  y: number;
}
export interface Size {
  width: number;
  height: 'auto' | number;
}

export interface Slide {
  id: string;
  title: string;
  content: string;
  layout: SlideLayout;
  visualSuggestion: string;
  imageUrl: string | null;
  backgroundColor: string;
  font: string;
  accentColor: string;
  titlePosition?: Position;
  titleSize?: Size;
  contentPosition?: Position;
  contentSize?: Size;
}

export interface Theme {
  name: string;
  backgroundColor: string;
  accentColor: string;
  textColor: string;
  titleColor?: string;
  font: string;
  description: string; // For the AI prompt
}

export interface ApiKeys {
  gemini: string[];
}

export interface AppSettings {
  defaultThemeName: string;
  defaultNumSlides: number;
  defaultRateLimitDelay: number;
  defaultImageModel: string;
  apiKeys: ApiKeys;
}