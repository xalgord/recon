import React, { useState } from 'react';
import { DownloadIcon, FileArchiveIcon, LoaderIcon } from './icons';

declare var jspdf: any;
declare var html2canvas: any;
declare var JSZip: any;

interface ExportControlsProps {
    themeName: string;
}

const ExportControls: React.FC<ExportControlsProps> = ({ themeName }) => {
    const [isExporting, setIsExporting] = useState<false | 'pdf' | 'zip'>(false);
    const [exportMessage, setExportMessage] = useState('');

    const handleExportPdf = async () => {
        setIsExporting('pdf');
        setExportMessage('Preparing PDF...');
        try {
            const { jsPDF } = jspdf;
            const pdf = new jsPDF({
                orientation: 'landscape',
                unit: 'mm',
                format: 'a4'
            });

            const slideElements = document.querySelectorAll('[id^="slide-container-"]');

            for (let i = 0; i < slideElements.length; i++) {
                setExportMessage(`Processing slide ${i + 1} of ${slideElements.length}...`);
                const element = slideElements[i] as HTMLElement;
                const rect = element.getBoundingClientRect();
                const canvas = await html2canvas(element, { 
                    scale: 2,
                    width: rect.width,
                    height: rect.height,
                    useCORS: true,
                    allowTaint: true,
                    logging: false,
                 });
                const imgData = canvas.toDataURL('image/png');

                const pdfWidth = pdf.internal.pageSize.getWidth();
                const pdfHeight = pdf.internal.pageSize.getHeight();

                if (i > 0) {
                    pdf.addPage();
                }
                pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
            }
            
            setExportMessage('Saving PDF...');
            const fileName = `presentation-${themeName.toLowerCase().replace(/\s/g, '-')}.pdf`;
            pdf.save(fileName);

        } catch (e) {
            console.error("Failed to export PDF", e);
            // You could set an error state here to show in the UI
        } finally {
            setIsExporting(false);
            setExportMessage('');
        }
    };

    const handleExportZip = async () => {
        setIsExporting('zip');
        setExportMessage('Preparing ZIP...');
        try {
            const zip = new JSZip();
            const slideElements = document.querySelectorAll('[id^="slide-container-"]');

            for (let i = 0; i < slideElements.length; i++) {
                setExportMessage(`Capturing slide ${i + 1} of ${slideElements.length}...`);
                const element = slideElements[i] as HTMLElement;
                const rect = element.getBoundingClientRect();
                const canvas = await html2canvas(element, { 
                    scale: 2,
                    width: rect.width,
                    height: rect.height,
                    useCORS: true,
                    allowTaint: true,
                    logging: false,
                });
                const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
                zip.file(`slide-${i + 1}.png`, blob as Blob);
            }
            
            setExportMessage('Generating ZIP file...');
            const content = await zip.generateAsync({ type: 'blob' });
            
            const link = document.createElement('a');
            link.href = URL.createObjectURL(content);
            const fileName = `presentation-${themeName.toLowerCase().replace(/\s/g, '-')}-images.zip`;
            link.download = fileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);

        } catch (e) {
            console.error("Failed to export ZIP", e);
        } finally {
            setIsExporting(false);
            setExportMessage('');
        }
    }


    return (
        <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-4 max-w-md mx-auto flex flex-col sm:flex-row items-center justify-center gap-4">
           {isExporting && <p className="text-sm text-gray-300">{exportMessage}</p>}
           {!isExporting && (
             <>
                <button
                    onClick={handleExportPdf}
                    disabled={!!isExporting}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2 bg-gray-700 text-white font-semibold rounded-lg hover:bg-gray-600 transition-all duration-200 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:text-gray-400"
                >
                    <DownloadIcon className="w-5 h-5" />
                    Export as PDF
                </button>
                 <button
                    onClick={handleExportZip}
                    disabled={!!isExporting}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2 bg-gray-700 text-white font-semibold rounded-lg hover:bg-gray-600 transition-all duration-200 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:text-gray-400"
                >
                    <FileArchiveIcon className="w-5 h-5" />
                    Export All as PNGs
                </button>
             </>
           )}
           {isExporting && <LoaderIcon className="w-6 h-6 animate-spin text-[#00FF99]" />}
        </div>
    );
};

export default ExportControls;