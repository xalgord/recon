import React, { useState, useEffect } from 'react';
import { XIcon, TrashIcon } from './icons';
import { Theme, AppSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSave: (settings: AppSettings) => void;
  themes: Theme[];
  imageModels: string[];
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, settings, onSave, themes, imageModels }) => {
  const [localSettings, setLocalSettings] = useState<AppSettings>(settings);
  const [newApiKey, setNewApiKey] = useState('');

  useEffect(() => {
    setLocalSettings(settings);
  }, [settings, isOpen]);

  if (!isOpen) {
    return null;
  }
  
  const handleSave = () => {
    onSave(localSettings);
    onClose();
  };
  
  const handleAddApiKey = () => {
    const trimmedKey = newApiKey.trim();
    if (trimmedKey && !localSettings.apiKeys.gemini.includes(trimmedKey)) {
        setLocalSettings(prev => ({
            ...prev,
            apiKeys: {
                ...prev.apiKeys,
                gemini: [...prev.apiKeys.gemini, trimmedKey]
            }
        }));
        setNewApiKey('');
    }
  };

  const handleRemoveApiKey = (keyToRemove: string) => {
    setLocalSettings(prev => ({
        ...prev,
        apiKeys: {
            ...prev.apiKeys,
            gemini: prev.apiKeys.gemini.filter(key => key !== keyToRemove)
        }
    }));
  };
  
  return (
    <div 
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 flex items-center justify-center"
      onClick={onClose}
    >
      <div 
        className="bg-gray-900 border border-gray-700 rounded-xl shadow-2xl w-full max-w-lg m-4 flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        <div className="p-6 border-b border-gray-700 flex justify-between items-center flex-shrink-0">
          <h2 className="text-xl font-bold text-white">App Settings</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        <div className="p-6 space-y-8 overflow-y-auto">
          {/* Preferences Section */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-200 border-b border-gray-700 pb-2">Preferences</h3>
            <div>
              <label htmlFor="defaultTheme" className="block text-sm font-medium text-gray-300 mb-2">Default Theme</label>
              <select id="defaultTheme" value={localSettings.defaultThemeName} onChange={e => setLocalSettings(prev => ({ ...prev, defaultThemeName: e.target.value }))} className="w-full bg-gray-800 border-gray-600 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-[#00FF99] focus:border-[#00FF99] transition duration-200">
                {themes.map(theme => (<option key={theme.name} value={theme.name}>{theme.name}</option>))}
              </select>
            </div>
             <div>
              <label htmlFor="defaultImageModel" className="block text-sm font-medium text-gray-300 mb-2">Default Image Generation Model</label>
              <select id="defaultImageModel" value={localSettings.defaultImageModel} onChange={e => setLocalSettings(prev => ({ ...prev, defaultImageModel: e.target.value }))} className="w-full bg-gray-800 border-gray-600 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-[#00FF99] focus:border-[#00FF99] transition duration-200">
                {imageModels.map(model => (<option key={model} value={model}>{model}</option>))}
              </select>
              <p className="text-xs text-gray-500 mt-1">
                  Choose the image model that works best with your API key.
              </p>
            </div>
          </div>
          {/* API Keys Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-200 border-b border-gray-700 pb-2">Google Gemini API Keys</h3>
            <div className="space-y-4">
              <p className="text-sm text-gray-400">
                  Add your own Gemini API keys for better performance and to avoid rate limits. If no keys are added, the app's default key will be used (with limitations).
              </p>
              <div className="flex gap-2">
                  <input type="password" value={newApiKey} onChange={e => setNewApiKey(e.target.value)} placeholder="Enter new Gemini API Key" className="flex-grow bg-gray-800 border-gray-600 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-[#00FF99] focus:border-[#00FF99] transition duration-200"/>
                  <button onClick={handleAddApiKey} className="px-4 py-2 bg-gray-700 text-white font-semibold rounded-lg hover:bg-gray-600 transition-colors">Add</button>
              </div>
              <div className="space-y-2 pt-4">
                  {localSettings.apiKeys.gemini.map(key => (
                      <div key={key} className="flex items-center justify-between bg-gray-800 p-2 rounded-md">
                          <span className="font-mono text-sm text-gray-400">{`${key.substring(0, 4)}...${key.substring(key.length - 4)}`}</span>
                          <button onClick={() => handleRemoveApiKey(key)} className="text-red-500 hover:text-red-400 p-1"><TrashIcon className="w-5 h-5" /></button>
                      </div>
                  ))}
                  {localSettings.apiKeys.gemini.length === 0 && (<p className="text-sm text-gray-500 text-center py-2">No custom Gemini API keys added.</p>)}
              </div>
            </div>
          </div>
        </div>
        <div className="p-4 bg-gray-900/50 border-t border-gray-700 text-right rounded-b-xl flex-shrink-0">
             <button onClick={handleSave} className="px-6 py-2 bg-[#00FF99] text-black font-bold rounded-lg hover:bg-opacity-80 transition-colors">Save & Close</button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;