import React, { useRef } from 'react';
import { Slide as SlideType, Position, Size } from '../types';
import { DownloadIcon, RefreshCwIcon, LoaderIcon } from './icons';
import DraggableResizable from './DraggableResizable';

declare var html2canvas: any;

interface SlideProps {
  slide: SlideType;
  index: number;
  onUpdate: (index: number, field: 'title' | 'content', value: string) => void;
  onTransformUpdate: (index: number, element: 'title' | 'content', position: Position, size: Size) => void;
  onRegenerateImage: (index: number) => void;
  isRegenerating: boolean;
  textColor: string;
  titleColor?: string;
}

const parseContent = (text: string) => {
    if (!text) return '';
    // Process markdown-style bolding: **text** -> <b>text</b>
    // Process markdown-style bullet points: - item -> • item
    return text
        .replace(/\*\*(.*?)\*\*/g, '<b>$1</b>')
        .replace(/^- /gm, '&bull; ')
        .replace(/\n/g, '<br />');
};

const EditableText: React.FC<{
  initialValue: string;
  onSave: (value: string) => void;
  className: string;
  placeholder: string;
}> = ({ initialValue, onSave, className, placeholder }) => {
    const elementRef = useRef<HTMLDivElement>(null);
    
    const handleBlur = () => {
        if (elementRef.current) {
            const text = elementRef.current.innerText;
            onSave(text);
        }
    };
    
    return (
        <div
          ref={elementRef}
          contentEditable
          suppressContentEditableWarning
          onBlur={handleBlur}
          className={`outline-none w-full h-full ${className} empty:before:content-[attr(data-placeholder)] empty:before:text-gray-500 empty:before:pointer-events-none`}
          data-placeholder={placeholder}
          dangerouslySetInnerHTML={{ __html: parseContent(initialValue) }}
        ></div>
    );
};

const Slide: React.FC<SlideProps> = ({ slide, index, onUpdate, onTransformUpdate, onRegenerateImage, isRegenerating, textColor, titleColor }) => {
  const slideContainerRef = useRef<HTMLDivElement>(null);
  
  const handleDownloadPng = async () => {
    const slideElement = document.getElementById(`slide-container-${index}`);
    if (slideElement) {
        try {
            const rect = slideElement.getBoundingClientRect();
            const canvas = await html2canvas(slideElement, { 
                scale: 2,
                width: rect.width,
                height: rect.height,
                useCORS: true,
                allowTaint: true,
            });
            const imageURL = canvas.toDataURL('image/png');
            const link = document.createElement('a');
            link.href = imageURL;
            link.download = `slide-${index + 1}.png`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (error) {
            console.error('Failed to download slide as PNG:', error);
        }
    }
  };

  const hasImage = slide.imageUrl && (
    slide.layout === 'IMAGE_LEFT_TEXT_RIGHT' || 
    slide.layout === 'IMAGE_RIGHT_TEXT_LEFT' || 
    slide.layout === 'FULL_BLEED_IMAGE' ||
    slide.layout === 'IMAGE_OVERLAP_LEFT' ||
    slide.layout === 'IMAGE_OVERLAP_RIGHT'
  );
  const hasTitle = slide.layout !== 'BLANK' && slide.title.trim() !== '';
  const hasContent = slide.layout !== 'BLANK' && slide.layout !== 'TITLE_ONLY' && slide.content.trim() !== '';
  const isTextOverImage = hasImage && (
    slide.layout === 'FULL_BLEED_IMAGE' ||
    slide.layout === 'IMAGE_OVERLAP_LEFT' ||
    slide.layout === 'IMAGE_OVERLAP_RIGHT'
  );
  
  const draggableWrapperStyle: React.CSSProperties = isTextOverImage ? {
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      borderRadius: '0.375rem',
      backdropFilter: 'blur(4px)',
      padding: '0.5rem',
  } : {};

  const getImageContainerStyle = (): React.CSSProperties => {
    switch(slide.layout) {
      case 'IMAGE_LEFT_TEXT_RIGHT': return { position: 'absolute', left: 0, top: 0, width: '50%', height: '100%' };
      case 'IMAGE_RIGHT_TEXT_LEFT': return { position: 'absolute', right: 0, top: 0, width: '50%', height: '100%' };
      case 'IMAGE_OVERLAP_LEFT': return { position: 'absolute', left: 0, top: 0, width: '60%', height: '100%' };
      case 'IMAGE_OVERLAP_RIGHT': return { position: 'absolute', right: 0, top: 0, width: '60%', height: '100%' };
      case 'FULL_BLEED_IMAGE': return { position: 'absolute', inset: 0, width: '100%', height: '100%' };
      default: return { display: 'none' };
    }
  }

  let slideContainerStyle: React.CSSProperties = {};
  if (slide.layout === 'IMAGE_RIGHT_TEXT_LEFT') {
    slideContainerStyle = { borderRight: `6px solid ${slide.accentColor}` };
  } else if (slide.layout === 'IMAGE_LEFT_TEXT_RIGHT') {
      slideContainerStyle = { borderLeft: `6px solid ${slide.accentColor}` };
  }

  return (
    <div className="w-full max-w-4xl mx-auto scroll-mt-4" id={`slide-${index}`}>
       <div 
        id={`slide-container-${index}`}
        ref={slideContainerRef}
        className="group relative w-full aspect-video bg-black rounded-lg shadow-2xl overflow-hidden border border-gray-700"
        style={slideContainerStyle}
      >
        <div className="absolute inset-0" style={{ color: textColor, fontFamily: slide.font, backgroundColor: slide.backgroundColor }}>
          {/* Background and Non-interactive elements */}
        </div>
        
        {/* Absolutely positioned content */}
        <div className="absolute inset-0">
            {hasImage && (
              <div style={getImageContainerStyle()} className="bg-gray-800 group/image">
                <img src={slide.imageUrl!} alt={slide.visualSuggestion} className="w-full h-full object-cover" />
                <div 
                  className="absolute inset-0 bg-black/50 flex items-center justify-center text-white opacity-0 group-hover/image:opacity-100 transition-opacity cursor-pointer"
                  onClick={() => onRegenerateImage(index)}
                  aria-label="Regenerate image"
                >
                  {isRegenerating ? (
                    <LoaderIcon className="w-8 h-8 animate-spin" />
                  ) : (
                    <RefreshCwIcon className="w-8 h-8" />
                  )}
                </div>
              </div>
            )}

            {slide.layout === 'FULL_BLEED_IMAGE' && <div className="absolute inset-0 bg-black/40"></div>}

            {hasTitle && slide.titlePosition && slide.titleSize && (
              <DraggableResizable
                boundsRef={slideContainerRef}
                initialPosition={slide.titlePosition}
                initialSize={slide.titleSize}
                onUpdate={(pos, size) => onTransformUpdate(index, 'title', pos, size)}
                wrapperStyle={draggableWrapperStyle}
              >
                <div style={{ color: titleColor || textColor }}>
                    <EditableText 
                    initialValue={slide.title}
                    onSave={(value) => onUpdate(index, 'title', value)}
                    className="text-2xl md:text-4xl font-bold"
                    placeholder="Editable Title"
                    key={`title-${slide.id}`}
                    />
                </div>
              </DraggableResizable>
            )}

            {hasContent && slide.contentPosition && slide.contentSize && (
               <DraggableResizable
                boundsRef={slideContainerRef}
                initialPosition={slide.contentPosition}
                initialSize={slide.contentSize}
                onUpdate={(pos, size) => onTransformUpdate(index, 'content', pos, size)}
                wrapperStyle={draggableWrapperStyle}
              >
                <EditableText 
                  initialValue={slide.content}
                  onSave={(value) => onUpdate(index, 'content', value)}
                  className="text-base md:text-lg whitespace-pre-wrap"
                  placeholder="Editable content..."
                  key={`content-${slide.id}`}
                />
              </DraggableResizable>
            )}
        </div>

        <button
            onClick={handleDownloadPng}
            className="absolute top-3 right-3 z-10 bg-black/50 p-2 rounded-full text-white/70 hover:text-white hover:bg-black/70 transition-all opacity-0 group-hover:opacity-100"
            aria-label="Download as PNG"
        >
            <DownloadIcon className="w-5 h-5" />
        </button>
      </div>
      <div className="text-center mt-2 text-sm text-gray-500">Slide {index + 1}</div>
    </div>
  );
};

export default Slide;