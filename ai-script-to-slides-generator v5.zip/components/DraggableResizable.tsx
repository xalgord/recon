import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Position, Size } from '../types';

interface DraggableResizableProps {
  children: React.ReactNode;
  boundsRef: React.RefObject<HTMLElement>;
  initialPosition: Position;
  initialSize: Size;
  onUpdate: (position: Position, size: Size) => void;
  wrapperStyle?: React.CSSProperties;
  minWidth?: number;
  minHeight?: number;
}

const DraggableResizable: React.FC<DraggableResizableProps> = ({
  children,
  boundsRef,
  initialPosition,
  initialSize,
  onUpdate,
  wrapperStyle = {},
  minWidth = 100,
  minHeight = 40,
}) => {
  const elementRef = useRef<HTMLDivElement>(null);
  
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [didMove, setDidMove] = useState(false);

  const dragInfo = useRef({
    startMouseX: 0,
    startMouseY: 0,
    startLeft: 0,
    startTop: 0,
    startWidth: 0,
    startHeight: 0,
  });

  const pxToPercent = useCallback((value: number, total: number) => (value / total) * 100, []);

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>, action: 'drag' | 'resize') => {
    if (!elementRef.current || !boundsRef.current) return;
    
    // Prevent starting a drag from a resize handle
    if (action === 'drag' && (e.target as HTMLElement).dataset.role === 'resize-handle') {
      return;
    }

    e.preventDefault();
    e.stopPropagation();

    if (action === 'drag') setIsDragging(true);
    if (action === 'resize') setIsResizing(true);
    setDidMove(false);

    const rect = elementRef.current.getBoundingClientRect();
    const parentRect = boundsRef.current.getBoundingClientRect();
    
    dragInfo.current = {
      startMouseX: e.clientX,
      startMouseY: e.clientY,
      startLeft: rect.left - parentRect.left,
      startTop: rect.top - parentRect.top,
      startWidth: rect.width,
      startHeight: rect.height,
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };
  
  const handleMouseMove = useCallback((e: MouseEvent) => {
    const currentIsDragging = isDragging || isResizing;
    if (!currentIsDragging) return;
    if (!elementRef.current || !boundsRef.current) return;
    
    const dx = e.clientX - dragInfo.current.startMouseX;
    const dy = e.clientY - dragInfo.current.startMouseY;

    // Detect if movement has occurred
    if (!didMove && (Math.abs(dx) > 3 || Math.abs(dy) > 3)) {
        setDidMove(true);
    }
    
    const parentRect = boundsRef.current.getBoundingClientRect();

    if (isDragging) {
      let newLeft = dragInfo.current.startLeft + dx;
      let newTop = dragInfo.current.startTop + dy;
      
      // Clamp to bounds
      newLeft = Math.max(0, Math.min(newLeft, parentRect.width - elementRef.current.offsetWidth));
      newTop = Math.max(0, Math.min(newTop, parentRect.height - elementRef.current.offsetHeight));
      
      elementRef.current.style.left = `${newLeft}px`;
      elementRef.current.style.top = `${newTop}px`;
    }

    if (isResizing) {
      let newWidth = dragInfo.current.startWidth + dx;
      let newHeight = dragInfo.current.startHeight + dy;

      newWidth = Math.max(minWidth, Math.min(newWidth, parentRect.width - elementRef.current.offsetLeft));
      newHeight = Math.max(minHeight, Math.min(newHeight, parentRect.height - elementRef.current.offsetTop));
      
      elementRef.current.style.width = `${newWidth}px`;
      elementRef.current.style.height = `${newHeight}px`;
    }
  }, [isDragging, isResizing, boundsRef, minWidth, minHeight, didMove]);

  const handleMouseUp = useCallback(() => {
    const currentIsDragging = isDragging || isResizing;
    if (!currentIsDragging) return;

    window.removeEventListener('mousemove', handleMouseMove);
    window.removeEventListener('mouseup', handleMouseUp);

    // If it was a drag/resize action that actually moved the element
    if (didMove) {
        if (!elementRef.current || !boundsRef.current) return;
        const parentRect = boundsRef.current.getBoundingClientRect();
        const finalRect = elementRef.current.getBoundingClientRect();

        const newPosition: Position = {
        x: pxToPercent(finalRect.left - parentRect.left, parentRect.width),
        y: pxToPercent(finalRect.top - parentRect.top, parentRect.height),
        };

        const newSize: Size = {
        width: pxToPercent(finalRect.width, parentRect.width),
        height: 'auto',
        };
        
        onUpdate(newPosition, newSize);
    } else {
        // It was just a click, focus the editable content
        // FIX: Replaced generic type argument with type assertion as querySelector is not a generic function.
        const editable = elementRef.current?.querySelector('[contenteditable=true]') as HTMLElement | null;
        if (editable) {
            editable.focus();
        }
    }

    setIsDragging(false);
    setIsResizing(false);
  }, [isDragging, isResizing, boundsRef, pxToPercent, onUpdate, handleMouseMove, didMove]);
  
  const style: React.CSSProperties = {
    position: 'absolute',
    left: `${initialPosition.x}%`,
    top: `${initialPosition.y}%`,
    width: `${initialSize.width}%`,
    height: initialSize.height === 'auto' ? 'auto' : `${initialSize.height}%`,
    cursor: isDragging ? 'grabbing' : 'grab',
    transition: isDragging || isResizing ? 'none' : 'box-shadow 0.2s ease, border-color 0.2s ease',
    ...wrapperStyle,
  };

  return (
    <div
      ref={elementRef}
      style={style}
      onMouseDown={(e) => handleMouseDown(e, 'drag')}
      className="p-2 box-border border border-transparent hover:border-[#00FF99] hover:border-dashed focus-within:border-[#00FF99] focus-within:border-solid rounded-md group/draggable"
    >
      {children}
      <div 
        onMouseDown={(e) => handleMouseDown(e, 'resize')}
        data-role="resize-handle"
        className="absolute -bottom-1 -right-1 w-4 h-4 bg-transparent cursor-se-resize opacity-0 group-hover/draggable:opacity-100"
      >
        <div className="w-full h-full border-2 border-[#00FF99] bg-gray-900 rounded-sm pointer-events-none"></div>
      </div>
    </div>
  );
};

export default DraggableResizable;
