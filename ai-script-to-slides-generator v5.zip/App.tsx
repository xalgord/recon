import React, { useState, useCallback, useEffect, useMemo } from 'react';
import * as geminiService from './services/geminiService';
import { Slide as SlideType, Theme, AppSettings, SlideLayout, Position, Size } from './types';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Slide from './components/Slide';
import Loader from './components/Loader';
import ExportControls from './components/ExportControls';
import SettingsModal from './components/SettingsModal';
import ApiGuideModal from './components/ApiGuideModal';

const THEMES: Theme[] = [
    { 
        name: 'Neon Droid',
        backgroundColor: '#000000',
        accentColor: '#00FF99',
        textColor: '#FFFFFF',
        titleColor: '#00FF99',
        font: "'Plus Jakarta Sans', sans-serif",
        description: 'A dark, futuristic theme with neon green accents. Think cyberpunk and high-tech.'
    },
    { 
        name: 'Professional',
        backgroundColor: '#FFFFFF',
        accentColor: '#0A74DA',
        textColor: '#1F2937',
        titleColor: '#0A74DA',
        font: "'Plus Jakarta Sans', sans-serif",
        description: 'A clean, modern, and corporate theme with a blue accent color. Professional and minimalist.'
    },
    {
        name: 'Sunset',
        backgroundColor: '#1E1B4B', // Indigo-900
        accentColor: '#F97316', // Orange-500
        textColor: '#E0E7FF', // Indigo-100
        titleColor: '#FBBF24', // Amber-400
        font: "'Lora', serif",
        description: 'A warm and creative theme with a dark indigo background and a vibrant orange accent. Evokes a sense of dusk or sunset.'
    },
    {
        name: 'Noir',
        backgroundColor: '#171717', // Neutral-900
        accentColor: '#FFFFFF',
        textColor: '#A3A3A3', // Neutral-400
        titleColor: '#FFFFFF',
        font: "'Lora', serif",
        description: 'A dramatic, high-contrast black and white theme. Suggests mystery, elegance, and a cinematic feel.'
    }
];

const IMAGE_MODELS = [
    'gemini-2.5-flash-image',
    'gemini-2.0-flash-preview-image-generation',
];

const APP_SETTINGS_KEY = 'ai-slide-deck-settings';

const DEFAULT_SETTINGS: AppSettings = {
  defaultThemeName: 'Neon Droid',
  defaultNumSlides: 10,
  defaultRateLimitDelay: 10,
  defaultImageModel: IMAGE_MODELS[0],
  apiKeys: { gemini: [] },
};

const PADDING_X = 6; // 6% horizontal padding from edges

const getDefaultLayoutConfig = (layout: SlideLayout) => {
    const config: any = {};
    switch (layout) {
        case 'TITLE_ONLY':
            config.titlePosition = { x: PADDING_X, y: 40 };
            config.titleSize = { width: 100 - 2 * PADDING_X, height: 'auto' };
            break;
        case 'TITLE_AND_CONTENT':
            config.titlePosition = { x: PADDING_X, y: 20 };
            config.titleSize = { width: 100 - 2 * PADDING_X, height: 'auto' };
            config.contentPosition = { x: PADDING_X, y: 45 };
            config.contentSize = { width: 100 - 2 * PADDING_X, height: 'auto' };
            break;
        case 'IMAGE_LEFT_TEXT_RIGHT':
            // Text on the right half
            config.titlePosition = { x: 50 + PADDING_X / 2, y: 20 };
            config.titleSize = { width: 50 - 1.5 * PADDING_X, height: 'auto' };
            config.contentPosition = { x: 50 + PADDING_X / 2, y: 45 };
            config.contentSize = { width: 50 - 1.5 * PADDING_X, height: 'auto' };
            break;
        case 'IMAGE_RIGHT_TEXT_LEFT':
            // Text on the left half
            config.titlePosition = { x: PADDING_X, y: 20 };
            config.titleSize = { width: 50 - 1.5 * PADDING_X, height: 'auto' };
            config.contentPosition = { x: PADDING_X, y: 45 };
            config.contentSize = { width: 50 - 1.5 * PADDING_X, height: 'auto' };
            break;
        case 'IMAGE_OVERLAP_LEFT':
             // Image is 60% on left, text starts around 40%
            config.titlePosition = { x: 40, y: 25 };
            config.titleSize = { width: 100 - 40 - PADDING_X, height: 'auto' };
            config.contentPosition = { x: 40, y: 50 };
            config.contentSize = { width: 100 - 40 - PADDING_X, height: 'auto' };
            break;
        case 'IMAGE_OVERLAP_RIGHT':
            // Image is 60% on right, text on left
            config.titlePosition = { x: PADDING_X, y: 25 };
            config.titleSize = { width: 100 - 40 - PADDING_X, height: 'auto' };
            config.contentPosition = { x: PADDING_X, y: 50 };
            config.contentSize = { width: 100 - 40 - PADDING_X, height: 'auto' };
            break;
        case 'FULL_BLEED_IMAGE':
            // Text on bottom left, like the example
            config.titlePosition = { x: PADDING_X, y: 65 };
            config.titleSize = { width: 60, height: 'auto' };
            config.contentPosition = { x: PADDING_X, y: 80 };
            config.contentSize = { width: 60, height: 'auto' };
            break;
        default: // BLANK or fallback
            config.titlePosition = { x: PADDING_X, y: 20 };
            config.titleSize = { width: 100 - 2 * PADDING_X, height: 'auto' };
            config.contentPosition = { x: PADDING_X, y: 40 };
            config.contentSize = { width: 100 - 2 * PADDING_X, height: 'auto' };
            break;
    }
    return config;
};


const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const App: React.FC = () => {
  const [slides, setSlides] = useState<SlideType[]>([]);
  const [script, setScript] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isApiGuideModalOpen, setIsApiGuideModalOpen] = useState(false);
  const [regeneratingSlideId, setRegeneratingSlideId] = useState<string | null>(null);

  const [appSettings, setAppSettings] = useState<AppSettings>(() => {
    try {
        const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
        if (storedSettings) {
            const parsed = JSON.parse(storedSettings);
            const apiKeys = {
                gemini: Array.isArray(parsed.apiKeys?.gemini) ? parsed.apiKeys.gemini : [],
            };
            return { ...DEFAULT_SETTINGS, ...parsed, apiKeys };
        }
        return DEFAULT_SETTINGS;
    } catch (error) {
        console.error("Could not load settings from local storage", error);
        return DEFAULT_SETTINGS;
    }
  });
  
  const activeApiKeys = useMemo(() => {
    const userKeys = appSettings.apiKeys.gemini;
    if (userKeys && userKeys.length > 0) {
        return userKeys.filter(Boolean);
    }
    if (process.env.API_KEY) {
        return process.env.API_KEY.split(',').map(k => k.trim()).filter(Boolean);
    }
    return [];
  }, [appSettings.apiKeys]);


  useEffect(() => {
    try {
        localStorage.setItem(APP_SETTINGS_KEY, JSON.stringify(appSettings));
    } catch (error) {
        console.error("Could not save settings to local storage", error);
    }
  }, [appSettings]);

  const [numSlides, setNumSlides] = useState<number>(appSettings.defaultNumSlides);
  const [rateLimitDelay, setRateLimitDelay] = useState<number>(appSettings.defaultRateLimitDelay);
  const [themes] = useState<Theme[]>(THEMES);
  const [selectedTheme, setSelectedTheme] = useState<Theme>(() => themes.find(t => t.name === appSettings.defaultThemeName) || themes[0]);
  
  useEffect(() => {
    setNumSlides(appSettings.defaultNumSlides);
    setRateLimitDelay(Math.max(10, appSettings.defaultRateLimitDelay)); // Enforce min 10s
    setSelectedTheme(themes.find(t => t.name === appSettings.defaultThemeName) || themes[0]);
  }, [appSettings, themes]);

  const handleGenerateSlides = useCallback(async () => {
    if (!script || numSlides <= 0) {
      setError('Please provide a script and a valid number of slides.');
      return;
    }
    
    const isUsingDefaultKeys = appSettings.apiKeys.gemini.length === 0;
    if (numSlides > 8 && isUsingDefaultKeys) {
        setIsApiGuideModalOpen(true);
        return;
    }

    if (activeApiKeys.length === 0) {
      setError(`No Gemini API Key found. Please add an API key in the settings.`);
      return;
    }

    setIsLoading(true);
    setError(null);
    setSlides([]);
    
    try {
      setLoadingMessage('Crafting slide content...');
      const slideContents = await geminiService.generateSlidesFromScript(activeApiKeys[0], script, numSlides, selectedTheme.description);

      const initialSlides: SlideType[] = slideContents.map((content, index) => ({
        ...content,
        id: `slide-${index}-${Date.now()}`,
        imageUrl: null,
        backgroundColor: selectedTheme.backgroundColor,
        font: selectedTheme.font,
        accentColor: selectedTheme.accentColor,
        ...getDefaultLayoutConfig(content.layout),
      }));
      setSlides(initialSlides);

      setLoadingMessage('Generating stunning visuals...');
      
      const slidesToUpdate = [...initialSlides];
      let generationStopped = false;
      let startKeyIndex = 0; // Tracks which key to start with for the next slide

      const primaryModel = appSettings.defaultImageModel;
      const secondaryModel = IMAGE_MODELS.find(m => m !== primaryModel) || IMAGE_MODELS[0];
      const modelsToTry = [primaryModel, secondaryModel];

      for (let i = 0; i < slidesToUpdate.length; i++) {
        const slide = slidesToUpdate[i];
        if (slide.visualSuggestion.startsWith('IMAGE:') || slide.visualSuggestion.startsWith('ILLUSTRATION:')) {
            let imageGenerated = false;
            
            let currentKeyIndex = startKeyIndex;
            let currentModelIndex = 0;
            const totalKeys = activeApiKeys.length;
            let fullCycleCount = 0;

            while (!imageGenerated && !generationStopped) {
                const apiKey = activeApiKeys[currentKeyIndex];
                const modelToUse = modelsToTry[currentModelIndex];

                try {
                    const modelNameShort = modelToUse.includes('2.5') ? '2.5-flash-image' : '2.0-flash-preview';
                    setLoadingMessage(`Slide ${i + 1}: Model '${modelNameShort}' | Key ${currentKeyIndex + 1}/${totalKeys}`);
                    
                    const imageUrl = await geminiService.generateImageForSlide(apiKey, slide.visualSuggestion, modelToUse);
                    
                    slidesToUpdate[i].imageUrl = imageUrl;
                    setSlides([...slidesToUpdate]);
                    imageGenerated = true;
                    startKeyIndex = (currentKeyIndex + 1) % totalKeys; // Set starting key for the next slide
                } catch (err) {
                    const isRateLimitError = err instanceof Error && (err.message.toLowerCase().includes('rate limit') || err.message.toLowerCase().includes('quota') || err.message.toLowerCase().includes('resource_exhausted'));
                    
                    if (isRateLimitError) {
                        console.warn(`Rate limit for key ${currentKeyIndex + 1} with model ${modelToUse}.`);
                        
                        // Move to the next key
                        currentKeyIndex = (currentKeyIndex + 1) % totalKeys;
                        
                        // If we've looped through all keys for the current model, move to the next model.
                        if (currentKeyIndex === startKeyIndex) {
                            currentModelIndex = (currentModelIndex + 1) % modelsToTry.length;
                            const newModelShort = modelsToTry[currentModelIndex].includes('2.5') ? '2.5-flash-image' : '2.0-flash-preview';
                            setLoadingMessage(`All keys failed. Switching to model '${newModelShort}'...`);

                            // If we've also looped through all models, we've completed a full cycle. Wait longer.
                            if (currentModelIndex === 0) {
                                fullCycleCount++;
                                const waitTime = Math.min(5 + (fullCycleCount * 5), 30); // 5s, 10s, 15s... max 30s
                                setLoadingMessage(`All keys & models rate-limited. Cooling down for ${waitTime}s...`);
                                await sleep(waitTime * 1000);
                            } else {
                               await sleep(2000); // Shorter pause for model switch
                            }
                        } else {
                            await sleep(2000); // 2s pause before trying the next key
                        }

                    } else {
                        // Non-recoverable error
                        const errorMessage = err instanceof Error ? err.message : 'Unknown error';
                        setError(`Failed on slide ${i + 1} with a non-recoverable error: ${errorMessage}`);
                        generationStopped = true;
                    }
                }
            } // end while

            if (generationStopped) break; // Break from the main for loop
        }
        
        if (i < slidesToUpdate.length - 1 && rateLimitDelay > 0) {
            await sleep(rateLimitDelay * 1000);
        }
      }
      
      setLoadingMessage(generationStopped ? 'Generation stopped.' : 'Presentation ready!');

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
        setTimeout(() => {
            setIsLoading(false);
            setLoadingMessage('');
        }, 2000);
    }
  }, [script, numSlides, selectedTheme, rateLimitDelay, activeApiKeys, appSettings]);

  const handleSlideUpdate = (index: number, field: 'title' | 'content', value: string) => {
    setSlides(prevSlides => {
      const newSlides = [...prevSlides];
      if (newSlides[index]) {
        newSlides[index][field] = value;
      }
      return newSlides;
    });
  };

  const handleSlideTransformUpdate = (index: number, element: 'title' | 'content', position: Position, size: Size) => {
    setSlides(prevSlides => {
        const newSlides = [...prevSlides];
        if (newSlides[index]) {
            if (element === 'title') {
                newSlides[index].titlePosition = position;
                newSlides[index].titleSize = size;
            } else {
                newSlides[index].contentPosition = position;
                newSlides[index].contentSize = size;
            }
        }
        return newSlides;
    });
  };

  const handleRegenerateImage = useCallback(async (index: number) => {
    const slide = slides[index];
    if (!slide || regeneratingSlideId) return;

    if (activeApiKeys.length === 0) {
        setError("Cannot regenerate image: No API Key found.");
        return;
    }

    setRegeneratingSlideId(slide.id);
    setError(null);

    try {
        const imageUrl = await geminiService.generateImageForSlide(activeApiKeys[0], slide.visualSuggestion, appSettings.defaultImageModel);
        setSlides(prevSlides => {
            const newSlides = [...prevSlides];
            if (newSlides[index]) {
                newSlides[index].imageUrl = imageUrl;
            }
            return newSlides;
        });
    } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to regenerate image.");
    } finally {
        setRegeneratingSlideId(null);
    }
  }, [slides, regeneratingSlideId, activeApiKeys, appSettings.defaultImageModel]);


  return (
    <div className="bg-gray-900 min-h-screen text-white">
      {isLoading && <Loader message={loadingMessage} />}
      <Header onOpenSettings={() => setIsSettingsOpen(true)} />
      <SettingsModal 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={appSettings}
        onSave={setAppSettings}
        themes={themes}
        imageModels={IMAGE_MODELS}
      />
      <ApiGuideModal
        isOpen={isApiGuideModalOpen}
        onClose={() => setIsApiGuideModalOpen(false)}
        onGoToSettings={() => {
            setIsApiGuideModalOpen(false);
            setIsSettingsOpen(true);
        }}
       />
      <main>
        <Dashboard
          script={script}
          setScript={setScript}
          numSlides={numSlides}
          setNumSlides={setNumSlides}
          rateLimitDelay={rateLimitDelay}
          setRateLimitDelay={setRateLimitDelay}
          onSubmit={handleGenerateSlides}
          isLoading={isLoading}
          themes={themes}
          selectedTheme={selectedTheme}
          onSelectTheme={setSelectedTheme}
        />
        {error && (
          <div className="container mx-auto px-4 text-center my-4">
            <p className="bg-red-900/50 text-red-300 p-3 rounded-lg border border-red-700">{error}</p>
          </div>
        )}
        {slides.length > 0 && (
          <div className="container mx-auto px-4 pb-16 space-y-12">
            <div className='text-center space-y-4'>
                <h2 className="text-3xl font-bold text-white">Your Generated Slides</h2>
                <ExportControls themeName={selectedTheme.name} />
            </div>
            {slides.map((slide, index) => (
              <Slide
                key={slide.id}
                slide={slide}
                index={index}
                onUpdate={handleSlideUpdate}
                onTransformUpdate={handleSlideTransformUpdate}
                onRegenerateImage={handleRegenerateImage}
                isRegenerating={regeneratingSlideId === slide.id}
                textColor={selectedTheme.textColor}
                titleColor={selectedTheme.titleColor}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default App;