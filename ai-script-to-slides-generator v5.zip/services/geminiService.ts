import { GoogleGenAI, Type, Modality } from "@google/genai";
import { Slide, SlideLayout } from '../types';

const slideLayouts: SlideLayout[] = [
    'TITLE_ONLY', 
    'TITLE_AND_CONTENT', 
    'IMAGE_LEFT_TEXT_RIGHT', 
    'IMAGE_RIGHT_TEXT_LEFT',
    'FULL_BLEED_IMAGE',
    'IMAGE_OVERLAP_LEFT',
    'IMAGE_OVERLAP_RIGHT',
    'BLANK'
];

const slideGenerationSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            title: {
                type: Type.STRING,
                description: 'A short, impactful title for the slide. Max 8 words.',
            },
            content: {
                type: Type.STRING,
                description: "Concise bullet points or a short paragraph. Use markdown for lists ('- Point 1'). Use markdown bold syntax ('**keyword**') to emphasize 1-2 important keywords. Max 40 words.",
            },
            layout: {
                type: Type.STRING,
                enum: slideLayouts,
                description: 'The layout for the slide.',
            },
            visualSuggestion: {
                type: Type.STRING,
                description: "A suggestion for a visual element. Must start with 'IMAGE:', 'ILLUSTRATION:', 'GRAPHIC:', 'LOGO:', or 'NONE'. For images/illustrations, provide a detailed description for an AI image generator. Example: 'IMAGE: A photorealistic image of a vintage typewriter on a wooden desk.'",
            },
        },
        required: ['title', 'content', 'layout', 'visualSuggestion'],
    },
};

export const generateSlidesFromScript = async (apiKey: string, script: string, numSlides: number, themeDescription: string): Promise<Omit<Slide, 'id' | 'imageUrl' | 'backgroundColor' | 'font' | 'accentColor'>[]> => {
    if (!apiKey) {
        throw new Error("API Key is missing.");
    }
    const ai = new GoogleGenAI({ apiKey });

    const prompt = `
        You are an expert presentation designer. Your task is to transform the following script into a visually engaging presentation with a specific theme.

        **Theme:** ${themeDescription}

        **Script:**
        ---
        ${script}
        ---

        **Instructions:**
        1.  Create exactly ${numSlides} slides.
        2.  Divide the script logically into ${numSlides} distinct sections for each slide.
        3.  For each slide, create a short, impactful title (max 8 words).
        4.  For the content, write a concise summary, either as a short paragraph or bullet points using markdown ('- Point 1'). The content should be easily readable on a presentation slide (max 40 words). **Crucially, use markdown bold syntax (\`**keyword**\`) to emphasize the 1-2 most important keywords in the content.**
        5.  For each slide, choose the best layout from the available options: ${slideLayouts.join(', ')}.
        6.  For each slide, provide a visual suggestion that perfectly matches the presentation's theme. It MUST be one of the following types:
            *   **IMAGE:** A detailed description for an AI image generator (e.g., "IMAGE: A minimalist black and white photo of a mountain peak.").
            *   **ILLUSTRATION:** A detailed description for an AI illustration (e.g., "ILLUSTRATION: A flat design style illustration of a person watering a growing plant.").
            *   **GRAPHIC:** A concept for a simple graphic (e.g., "GRAPHIC: An upward trending arrow.").
            *   **LOGO:** A suggestion for a logo (e.g., "LOGO: The Google logo.").
            *   **NONE:** If no visual is suitable for the slide.
        7.  Ensure the response is a valid JSON array matching the provided schema.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: slideGenerationSchema,
            },
        });

        const jsonString = response.text;
        const slidesData = JSON.parse(jsonString);

        if (!Array.isArray(slidesData)) {
            throw new Error("API did not return a valid array of slides.");
        }
        
        return slidesData;

    } catch (error) {
        console.error("Error generating slides:", error);
        throw new Error("Failed to generate slide content. Please check your API key and script, then try again.");
    }
};

export const generateImageForSlide = async (apiKey: string, visualSuggestion: string, modelName: string): Promise<string | null> => {
    if (!apiKey) {
        throw new Error("API Key is missing.");
    }
    const imagePrompt = visualSuggestion.replace(/^(IMAGE:|ILLUSTRATION:)\s*/, '');
    if (!imagePrompt || imagePrompt === visualSuggestion) {
        return null;
    }
    
    const ai = new GoogleGenAI({ apiKey });
    
    // Conditionally set response modalities based on the model name.
    // The older 'gemini-2.0-flash-preview-image-generation' model requires both TEXT and IMAGE modalities,
    // while the newer 'gemini-2.5-flash-image' requires only IMAGE.
    const responseModalities = modelName === 'gemini-2.0-flash-preview-image-generation'
        ? [Modality.TEXT, Modality.IMAGE]
        : [Modality.IMAGE];

    try {
        const response = await ai.models.generateContent({
            model: modelName,
            contents: {
                parts: [{ text: `Generate a high-quality, visually stunning image for a presentation slide with a 16:9 aspect ratio. The style should be modern, professional, and cinematic. The image must be: ${imagePrompt}` }],
            },
            config: {
                responseModalities: responseModalities,
            },
        });
        
        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
              const base64ImageBytes: string = part.inlineData.data;
              return `data:image/png;base64,${base64ImageBytes}`;
            }
        }
        return null;
    } catch (error: any) {
        console.error("Error generating image:", error);
        
        let errorContent = '';
        if (error instanceof Error) {
            // If it's an Error object, its message might contain the JSON string with details.
            errorContent = error.message;
        } else if (typeof error === 'object' && error !== null) {
            // If it's a plain object from the API, stringify it.
            errorContent = JSON.stringify(error);
        } else {
            // Fallback for strings or other primitives.
            errorContent = String(error);
        }
        const errorString = errorContent.toLowerCase();

        if (errorString.includes('429') || errorString.includes('quota') || errorString.includes('resource_exhausted')) {
            throw new Error("Rate limit exceeded with the current API key. Please check your API plan, try again, or add more keys for rotation.");
        }
        if (errorString.includes('api key not valid')) {
            throw new Error("The provided API key is not valid. Please check the key in your settings.");
        }
        throw new Error("An unexpected error occurred while generating the image.");
    }
};