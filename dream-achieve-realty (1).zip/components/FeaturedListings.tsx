import React from 'react';
import { PROPERTIES } from '../constants';
import PropertyCard from './PropertyCard';

const FeaturedListings: React.FC = () => {
  return (
    <section id="listings" className="py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-brand-blue-dark font-serif">Featured Properties</h2>
          <p className="mt-4 text-lg text-slate-500 max-w-2xl mx-auto">Discover our handpicked selection of premium properties.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PROPERTIES.map((property) => (
            <PropertyCard key={property.id} property={property} />
          ))}
        </div>
        <div className="text-center mt-16">
            <a href="#" className="inline-block px-8 py-3 bg-brand-blue text-white rounded-lg font-bold text-base hover:bg-brand-blue-dark transition-all duration-300 shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
                View All Listings
            </a>
        </div>
      </div>
    </section>
  );
};

export default FeaturedListings;