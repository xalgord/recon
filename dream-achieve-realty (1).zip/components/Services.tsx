import React from 'react';

const ServiceCard: React.FC<{ icon: React.ReactNode; title: string; children: React.ReactNode }> = ({ icon, title, children }) => (
    <div className="bg-white rounded-2xl shadow-lg hover:shadow-2xl p-8 text-center transform hover:-translate-y-2 transition-all duration-500 flex flex-col items-center group border-t-4 border-transparent hover:border-brand-yellow">
        <div className="bg-brand-blue group-hover:bg-brand-blue-dark text-brand-yellow rounded-full p-5 mb-6 inline-flex transition-colors duration-300">
            {icon}
        </div>
        <h3 className="text-2xl font-bold text-brand-blue-dark mb-3 font-serif">{title}</h3>
        <p className="text-slate-600 leading-relaxed">{children}</p>
    </div>
);

const ResidentialIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
        <polyline points="9 22 9 12 15 12 15 22"></polyline>
    </svg>
);
const CommercialIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M18 20V4H6v16" /><path d="M12 20V4" /><path d="M4 20h16" />
    </svg>
);
const IndustrialIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M4 22v-6" /><path d="M8 22v-4" /><path d="M12 22v-8" /><path d="M16 22v-4" /><path d="M20 22v-6" /><path d="M4 4l4-2l4 2l4-2l4 2" /><path d="M4 10h16" />
    </svg>
);


const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-brand-gray">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-brand-blue-dark font-serif">Our Expertise</h2>
          <p className="mt-4 text-lg text-slate-500 max-w-2xl mx-auto">Comprehensive real estate solutions, tailored to your needs in Tricity, Mohali.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <ServiceCard icon={<ResidentialIcon />} title="Residential Properties">
            Whether you're buying or selling, we help you find the perfect home or buyer in Mohali's finest neighborhoods.
          </ServiceCard>
          <ServiceCard icon={<CommercialIcon />} title="Commercial Properties">
            From retail spaces to office buildings, we provide strategic advice to help your business find the right location to thrive.
          </ServiceCard>
          <ServiceCard icon={<IndustrialIcon />} title="Industrial Properties">
            We specialize in sourcing and negotiating deals for warehouses, manufacturing units, and industrial plots in the region.
          </ServiceCard>
        </div>
      </div>
    </section>
  );
};

export default Services;