import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative h-[70vh] md:h-[85vh] flex items-center justify-center text-white">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=2070&auto=format&fit=crop')" }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-t from-brand-blue-dark/90 via-brand-blue-dark/60 to-transparent"></div>
      <div className="relative z-10 container mx-auto px-4 text-center">
        <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl font-bold mb-4 drop-shadow-lg">
          Your Premier Real Estate Partner in Tricity, Mohali
        </h1>
        <p className="text-lg md:text-xl mb-10 max-w-3xl mx-auto text-slate-200 drop-shadow-md">
          Specializing in Commercial, Residential, and Industrial properties. We provide expert guidance to help you find the perfect space in Punjab.
        </p>
        <a href="#services" className="inline-block px-10 py-4 bg-brand-yellow text-brand-blue-dark rounded-lg font-bold text-lg hover:bg-opacity-90 transition-all duration-300 shadow-lg transform hover:-translate-y-1 hover:shadow-2xl">
            Explore Our Services
        </a>
      </div>
    </section>
  );
};

export default Hero;