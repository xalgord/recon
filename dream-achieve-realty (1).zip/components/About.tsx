import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div className="rounded-xl overflow-hidden shadow-2xl aspect-w-1 aspect-h-1">
            <img 
              src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?q=80&w=2070&auto=format&fit=crop" 
              alt="A beautiful modern house, representing the properties Dream Achieve Realty offers."
              className="w-full h-full object-cover" 
            />
          </div>
          <div>
            <span className="inline-block bg-yellow-100 text-brand-yellow font-bold text-sm px-3 py-1 rounded-full mb-4">Our Mission</span>
            <h2 className="mt-2 text-4xl md:text-5xl font-bold text-brand-blue-dark font-serif">
              Your Trusted Real Estate Advisors in Mohali
            </h2>
            <p className="mt-6 text-lg text-slate-600 leading-relaxed">
              At Dream Achieve Realty, we are more than just agents; we are your strategic partners in navigating the dynamic real estate market of Tricity, Mohali. Our expertise spans across commercial, residential, and industrial sectors.
            </p>
            <p className="mt-4 text-lg text-slate-600 leading-relaxed">
             We are committed to building lasting relationships based on trust and transparency, providing you with the insights and support needed to make informed decisions and achieve your property goals.
            </p>
            <div className="mt-8">
              <a href="#contact" className="inline-block px-8 py-3 bg-brand-blue text-white rounded-lg font-bold text-base hover:bg-brand-blue-dark transition-all duration-300 shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
                Get In Touch
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;