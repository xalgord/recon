import React from 'react';
import { TESTIMONIALS } from '../constants';

const QuoteIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} width="48" height="36" viewBox="0 0 48 36" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 36V18.2857C0 12.0952 2.13333 7.2381 6.4 3.71429C10.6667 0.190476 15.8667 0 22 2.14286V9C17.7333 7.80952 14.6667 8.30952 12.8 10.5C10.9333 12.6905 10 15.7619 10 19.7143H21V36H0ZM26 36V18.2857C26 12.0952 28.1333 7.2381 32.4 3.71429C36.6667 0.190476 41.8667 0 48 2.14286V9C43.7333 7.80952 40.6667 8.30952 38.8 10.5C36.9333 12.6905 36 15.7619 36 19.7143H47V36H26Z" fill="currentColor"/>
    </svg>
);


const Testimonials: React.FC = () => {
  return (
    <section id="testimonials" className="py-24 bg-brand-gray">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-brand-blue-dark font-serif">What Our Clients Say</h2>
          <p className="mt-4 text-lg text-slate-500 max-w-2xl mx-auto">Real stories from real people who achieved their dreams with us.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {TESTIMONIALS.map((testimonial) => (
            <div key={testimonial.id} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-shadow duration-300 flex flex-col border-t-4 border-brand-blue">
              <QuoteIcon className="w-10 h-auto text-brand-yellow mb-5" />
              <p className="text-slate-600 leading-relaxed flex-grow italic">"{testimonial.quote}"</p>
              <div className="mt-6 flex items-center">
                <img src={testimonial.avatar} alt={testimonial.name} className="w-16 h-16 rounded-full object-cover border-4 border-white shadow-md" />
                <div className="ml-4">
                  <p className="font-bold text-brand-blue-dark text-lg">{testimonial.name}</p>
                  <p className="text-sm text-slate-500">{testimonial.title}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;