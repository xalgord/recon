import React from 'react';
// FIX: Import the 'Property' type.
import type { Testimonial, Property } from './types';

export const NAV_LINKS = [
  { href: '#services', label: 'Services' },
  { href: '#about', label: 'About Us' },
  { href: '#testimonials', label: 'Testimonials' },
  { href: '#contact', label: 'Contact' },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: 'Aarav Sharma',
    title: 'Commercial Client',
    quote: "Dream Achieve Realty's deep knowledge of the Mohali commercial market was invaluable. They helped us secure the perfect office space with incredible professionalism and efficiency.",
    avatar: 'https://picsum.photos/seed/avatar1/100/100',
  },
  {
    id: 2,
    name: 'Priya Kaur',
    title: 'Residential Homeowner',
    quote: "As a family, we were looking for a home, not just a house. Their team guided us through every step of finding our dream home in Tricity. Their local expertise is unmatched.",
    avatar: 'https://picsum.photos/seed/avatar2/100/100',
  },
  {
    id: 3,
    name: 'Vikram Singh Logistics',
    title: 'Industrial Partner',
    quote: "For our industrial and warehousing needs, Dream Achieve Realty were the ultimate professionals. They understood our specific requirements and found a location that was perfect for our operations.",
    avatar: 'https://picsum.photos/seed/avatar3/100/100',
  },
];

// FIX: Define and export the PROPERTIES constant with sample data.
export const PROPERTIES: Property[] = [
  {
    id: 1,
    address: '123 Modern Avenue',
    city: 'Sector 70, Mohali',
    price: 7500000,
    image: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?q=80&w=1974&auto=format&fit=crop',
    type: 'For Sale',
    beds: 3,
    baths: 2,
    sqft: 1800,
  },
  {
    id: 2,
    address: '456 Corporate Plaza',
    city: 'Industrial Area, Mohali',
    price: 45000,
    image: 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?q=80&w=2070&auto=format&fit=crop',
    type: 'For Rent',
    beds: 0,
    baths: 4,
    sqft: 5000,
  },
  {
    id: 3,
    address: '789 Skyline Heights',
    city: 'Sector 91, Mohali',
    price: 12500000,
    image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?q=80&w=2070&auto=format&fit=crop',
    type: 'For Sale',
    beds: 4,
    baths: 4,
    sqft: 3200,
  },
];

export const Logo: React.FC<{ className?: string }> = ({ className }) => (
    <div className={`relative font-bold text-2xl ${className}`}>
        <svg width="160" height="80" viewBox="0 0 160 80" className="h-12 w-auto">
            <defs>
                <clipPath id="clipPathForA">
                    <path d="M72 38 L88 38 L88 56 L72 56 Z" />
                </clipPath>
            </defs>

            {/* <!-- Roof --> */}
            <path d="M10 40 L80 10 L150 40" stroke="#1e3a8a" strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
            
            {/* <!-- "A" as house body --> */}
            <path d="M72 38 L80 25 L88 38 L88 56 L72 56 Z" fill="#facc15" />
            
            {/* <!-- "D" --> */}
            <path d="M15 65 C 15 40, 60 40, 60 40 L 60 65 L 15 65" fill="#1e3a8a" />
            <circle cx="37.5" cy="52.5" r="12.5" fill="white" />
            <path d="M25 65 C 25 45, 50 45, 50 45 L 50 65 L 25 65" fill="#1e3a8a" />
            
            {/* <!-- "R" --> */}
            <path d="M100 65 L100 40 C 100 30, 120 30, 120 40 C 120 50, 100 50, 100 50 L 125 65" fill="#1e3a8a" />
            <path d="M107 50 L107 43 L115 43 C 117 43, 117 46, 115 46 L 107 46" fill="white"/>

            {/* <!-- Door --> */}
            <path d="M76 56 L 76 48 C 76 44, 84 44, 84 48 L 84 56 Z" fill="#3b82f6" />
            
            {/* <!-- Windows --> */}
            <rect x="75" y="32" width="4" height="4" fill="white" />
            <rect x="81" y="32" width="4" height="4" fill="white" />
            
            {/* <!-- Key --> */}
            <g fill="#facc15" stroke="#facc15" strokeWidth="3" strokeLinecap="round">
                <line x1="125" y1="35" x2="125" y2="10" />
                <circle cx="125" cy="10" r="6" fill="none" />
                <circle cx="125" cy="7" r="2" />
                <circle cx="125" cy="13" r="2" />
                <circle cx="122" cy="10" r="2" />
                <circle cx="128" cy="10" r="2" />
                <path d="M125 32 L130 32" />
                <path d="M125 28 L130 28" />
            </g>
        </svg>
        <div className="absolute -bottom-4 left-1 tracking-widest text-xs">
            <span className="text-[#1e3a8a]">DREAM ACHIEVE</span>
            <span className="text-[#facc15] ml-1">REALTY</span>
        </div>
    </div>
);