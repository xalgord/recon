
import React from 'react';
import { SparklesIcon } from './icons';

interface DashboardProps {
  script: string;
  setScript: (script: string) => void;
  numSlides: number;
  setNumSlides: (num: number) => void;
  onSubmit: () => void;
  isLoading: boolean;
}

const Dashboard: React.FC<DashboardProps> = ({
  script,
  setScript,
  numSlides,
  setNumSlides,
  onSubmit,
  isLoading,
}) => {
  const handleNumSlidesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value, 10);
    if (value > 0) {
      setNumSlides(value);
    } else if (e.target.value === '') {
        setNumSlides(0);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 md:py-16">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl md:text-5xl font-bold text-center text-white mb-2">
          Transform Your Script into a <span className="text-[#00FF99]">Presentation</span>
        </h2>
        <p className="text-center text-gray-400 mb-10 text-lg">
          Paste your script, choose the number of slides, and let AI do the rest.
        </p>

        <div className="bg-gray-900/50 border border-gray-700 rounded-xl p-6 space-y-6 backdrop-blur-lg">
          <div>
            <label htmlFor="script" className="block text-sm font-medium text-gray-300 mb-2">
              YouTube Script
            </label>
            <textarea
              id="script"
              rows={12}
              className="w-full bg-gray-800 border-gray-600 rounded-lg p-4 text-gray-200 focus:ring-2 focus:ring-[#00FF99] focus:border-[#00FF99] transition duration-200 placeholder-gray-500"
              placeholder="Paste your script here..."
              value={script}
              onChange={(e) => setScript(e.target.value)}
              disabled={isLoading}
            />
          </div>
          <div>
            <label htmlFor="numSlides" className="block text-sm font-medium text-gray-300 mb-2">
              Number of Slides
            </label>
            <input
              type="number"
              id="numSlides"
              className="w-full md:w-1/4 bg-gray-800 border-gray-600 rounded-lg p-4 text-gray-200 focus:ring-2 focus:ring-[#00FF99] focus:border-[#00FF99] transition duration-200"
              value={numSlides === 0 ? '' : numSlides}
              onChange={handleNumSlidesChange}
              min="1"
              placeholder="e.g., 10"
              disabled={isLoading}
            />
          </div>
          <div className="text-center pt-2">
            <button
              onClick={onSubmit}
              disabled={isLoading || !script || numSlides <= 0}
              className="w-full md:w-auto inline-flex items-center justify-center gap-2 px-12 py-4 bg-[#00FF99] text-black font-bold rounded-lg hover:bg-opacity-80 transition-all duration-200 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:text-gray-400 focus:outline-none focus:ring-4 focus:ring-[#00ff99]/50"
            >
              <SparklesIcon className="w-5 h-5" />
              Generate Slides
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
