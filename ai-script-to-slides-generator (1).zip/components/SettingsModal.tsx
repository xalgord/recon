import React, { useState } from 'react';
import { XIcon, TrashIcon } from './icons';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  apiKeys: string[];
  setApiKeys: (keys: string[]) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, apiKeys, setApiKeys }) => {
  const [newKey, setNewKey] = useState('');

  if (!isOpen) {
    return null;
  }
  
  const handleAddKey = () => {
    if (newKey.trim() && !apiKeys.includes(newKey.trim())) {
      setApiKeys([...apiKeys, newKey.trim()]);
      setNewKey('');
    }
  };

  const handleRemoveKey = (keyToRemove: string) => {
    setApiKeys(apiKeys.filter(key => key !== keyToRemove));
  };
  
  const maskApiKey = (key: string) => {
      if (key.length < 8) return '***';
      return `${key.substring(0, 4)}...${key.substring(key.length - 4)}`;
  }

  return (
    <div 
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 flex items-center justify-center"
      onClick={onClose}
    >
      <div 
        className="bg-gray-900 border border-gray-700 rounded-xl shadow-2xl w-full max-w-md m-4"
        onClick={e => e.stopPropagation()}
      >
        <div className="p-6 border-b border-gray-700 flex justify-between items-center">
          <h2 className="text-xl font-bold text-white">API Key Settings</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        <div className="p-6 space-y-6">
          <div>
            <label htmlFor="apiKeyInput" className="block text-sm font-medium text-gray-300 mb-2">
              Add New Gemini API Key
            </label>
            <div className="flex gap-2">
              <input
                type="password"
                id="apiKeyInput"
                value={newKey}
                onChange={(e) => setNewKey(e.target.value)}
                className="flex-grow bg-gray-800 border-gray-600 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-[#00FF99] focus:border-[#00FF99] transition duration-200"
                placeholder="Enter your API key"
              />
              <button
                onClick={handleAddKey}
                className="px-4 py-2 bg-[#00FF99] text-black font-bold rounded-lg hover:bg-opacity-80 transition-colors disabled:bg-gray-600 disabled:cursor-not-allowed"
                disabled={!newKey.trim()}
              >
                Add
              </button>
            </div>
          </div>
          
          <div>
            <h3 className="text-md font-semibold text-gray-200 mb-3">Managed API Keys</h3>
            {apiKeys.length > 0 ? (
                <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                    {apiKeys.map((key) => (
                        <div key={key} className="flex items-center justify-between bg-gray-800 p-3 rounded-lg">
                            <span className="font-mono text-sm text-gray-400">{maskApiKey(key)}</span>
                            <button 
                                onClick={() => handleRemoveKey(key)}
                                className="text-gray-500 hover:text-red-500 transition-colors"
                                aria-label="Remove API Key"
                            >
                                <TrashIcon className="w-5 h-5" />
                            </button>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-6 bg-gray-800/50 rounded-lg">
                    <p className="text-gray-400">No API keys added yet.</p>
                </div>
            )}
            <p className="text-xs text-gray-500 mt-4">
                Your keys are stored only in your browser's local storage and are never sent to our servers. Adding multiple keys can help avoid rate limits.
            </p>
          </div>
        </div>
        <div className="p-4 bg-gray-900/50 border-t border-gray-700 text-right rounded-b-xl">
             <button
                onClick={onClose}
                className="px-6 py-2 bg-gray-700 text-white font-semibold rounded-lg hover:bg-gray-600 transition-colors"
              >
                Done
              </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
