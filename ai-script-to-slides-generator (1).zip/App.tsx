import React, { useState, useCallback, useEffect } from 'react';
import { generateSlidesFromScript, generateImageForSlide } from './services/geminiService';
import { Slide as SlideType } from './types';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Slide from './components/Slide';
import Loader from './components/Loader';
import SettingsModal from './components/SettingsModal';

const App: React.FC = () => {
  const [slides, setSlides] = useState<SlideType[]>([]);
  const [script, setScript] = useState<string>('');
  const [numSlides, setNumSlides] = useState<number>(10);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [apiKeys, setApiKeys] = useState<string[]>([]);

  useEffect(() => {
    try {
      const storedKeys = localStorage.getItem('apiKeys');
      if (storedKeys) {
        setApiKeys(JSON.parse(storedKeys));
      }
    } catch (e) {
      console.error("Failed to parse API keys from localStorage", e);
    }
  }, []);
  
  const handleSetApiKeys = (keys: string[]) => {
    setApiKeys(keys);
    localStorage.setItem('apiKeys', JSON.stringify(keys));
  }

  const handleGenerateSlides = useCallback(async () => {
    if (apiKeys.length === 0) {
        setError('Please add at least one API key in the settings before generating slides.');
        setIsSettingsOpen(true);
        return;
    }
    if (!script || numSlides <= 0) {
      setError('Please provide a script and a valid number of slides.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setSlides([]);
    
    try {
      setLoadingMessage('Crafting slide content...');
      const slideContents = await generateSlidesFromScript(script, numSlides, apiKeys[0]);

      const initialSlides: SlideType[] = slideContents.map((content, index) => ({
        ...content,
        id: `slide-${index}-${Date.now()}`,
        imageUrl: null,
        backgroundColor: '#000000',
        font: 'Inter, sans-serif',
        accentColor: '#00FF99',
      }));
      setSlides(initialSlides);

      setLoadingMessage('Generating stunning visuals...');
      
      const slidesToUpdate = [...initialSlides];
      for (let i = 0; i < slidesToUpdate.length; i++) {
        const slide = slidesToUpdate[i];
        if (slide.visualSuggestion.startsWith('IMAGE:') || slide.visualSuggestion.startsWith('ILLUSTRATION:')) {
            setLoadingMessage(`Generating visual for slide ${i + 1} of ${slidesToUpdate.length}...`);
            try {
                // Rotate through API keys to distribute the load
                const currentApiKey = apiKeys[i % apiKeys.length];
                const imageUrl = await generateImageForSlide(slide.visualSuggestion, currentApiKey);
                
                // Update the specific slide with the new image URL
                slidesToUpdate[i].imageUrl = imageUrl;
                // Update the state to reflect the change immediately on the UI
                setSlides([...slidesToUpdate]);

            } catch (imageError) {
                console.error(`Failed to generate image for slide ${i + 1}:`, imageError);
                // Set an error message but continue the process for other slides
                setError(`Could not generate image for slide ${i + 1}. You may have exceeded your API quota.`);
            }
        }
      }

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [script, numSlides, apiKeys]);

  const handleSlideUpdate = (index: number, field: 'title' | 'content', value: string) => {
    setSlides(prevSlides => {
      const newSlides = [...prevSlides];
      if (newSlides[index]) {
        newSlides[index][field] = value;
      }
      return newSlides;
    });
  };

  return (
    <div className="bg-gray-900 min-h-screen text-white">
      {isLoading && <Loader message={loadingMessage} />}
      <SettingsModal 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        apiKeys={apiKeys}
        setApiKeys={handleSetApiKeys}
      />
      <Header onOpenSettings={() => setIsSettingsOpen(true)} />
      <main>
        <Dashboard
          script={script}
          setScript={setScript}
          numSlides={numSlides}
          setNumSlides={setNumSlides}
          onSubmit={handleGenerateSlides}
          isLoading={isLoading}
        />
        {error && (
          <div className="container mx-auto px-4 text-center my-4">
            <p className="bg-red-900/50 text-red-300 p-3 rounded-lg border border-red-700">{error}</p>
          </div>
        )}
        {slides.length > 0 && (
          <div className="container mx-auto px-4 pb-16 space-y-12">
            <h2 className="text-3xl font-bold text-center text-white mb-8">Your Generated Slides</h2>
            {slides.map((slide, index) => (
              <Slide
                key={slide.id}
                slide={slide}
                index={index}
                onUpdate={handleSlideUpdate}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default App;