
export type SlideLayout = 
  | 'TITLE_ONLY' 
  | 'TITLE_AND_CONTENT' 
  | 'IMAGE_LEFT_TEXT_RIGHT' 
  | 'IMAGE_RIGHT_TEXT_LEFT'
  | 'FULL_BLEED_IMAGE'
  | 'BLANK';

export interface Slide {
  id: string;
  title: string;
  content: string;
  layout: SlideLayout;
  visualSuggestion: string;
  imageUrl: string | null;
  backgroundColor: string;
  font: string;
  accentColor: string;
}
