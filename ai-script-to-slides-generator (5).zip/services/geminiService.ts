import { GoogleGenAI, Type, Modality } from "@google/genai";
import { Slide, SlideLayout } from '../types';

const slideLayouts: SlideLayout[] = [
    'TITLE_ONLY', 
    'TITLE_AND_CONTENT', 
    'IMAGE_LEFT_TEXT_RIGHT', 
    'IMAGE_RIGHT_TEXT_LEFT',
    'FULL_BLEED_IMAGE',
    'BLANK'
];

const slideGenerationSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            title: {
                type: Type.STRING,
                description: 'A short, impactful title for the slide. Max 10 words.',
            },
            content: {
                type: Type.STRING,
                description: 'Concise bullet points or a short paragraph. Use markdown for lists. Max 50 words.',
            },
            layout: {
                type: Type.STRING,
                enum: slideLayouts,
                description: 'The layout for the slide.',
            },
            visualSuggestion: {
                type: Type.STRING,
                description: "A suggestion for a visual element. Must start with 'IMAGE:', 'ILLUSTRATION:', 'GRAPHIC:', 'LOGO:', or 'NONE'. For images/illustrations, provide a detailed description for an AI image generator. Example: 'IMAGE: A photorealistic image of a vintage typewriter on a wooden desk.'",
            },
        },
        required: ['title', 'content', 'layout', 'visualSuggestion'],
    },
};

export const generateSlidesFromScript = async (script: string, numSlides: number, themeDescription: string): Promise<Omit<Slide, 'id' | 'imageUrl' | 'backgroundColor' | 'font' | 'accentColor'>[]> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

    const prompt = `
        You are an expert presentation designer. Your task is to transform the following script into a visually engaging presentation with a specific theme.

        **Theme:** ${themeDescription}

        **Script:**
        ---
        ${script}
        ---

        **Instructions:**
        1.  Create exactly ${numSlides} slides.
        2.  Divide the script logically into ${numSlides} distinct sections for each slide.
        3.  For each slide, create a short, impactful title and concise content (bullet points or a short paragraph). Summarize the script content for a presentation format.
        4.  For each slide, choose the best layout from the available options: ${slideLayouts.join(', ')}.
        5.  For each slide, provide a visual suggestion that perfectly matches the presentation's theme. It MUST be one of the following types:
            *   **IMAGE:** A detailed description for an AI image generator (e.g., "IMAGE: A minimalist black and white photo of a mountain peak.").
            *   **ILLUSTRATION:** A detailed description for an AI illustration (e.g., "ILLUSTRATION: A flat design style illustration of a person watering a growing plant.").
            *   **GRAPHIC:** A concept for a simple graphic (e.g., "GRAPHIC: An upward trending arrow.").
            *   **LOGO:** A suggestion for a logo (e.g., "LOGO: The Google logo.").
            *   **NONE:** If no visual is suitable for the slide.
        6.  Ensure the response is a valid JSON array matching the provided schema.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: slideGenerationSchema,
            },
        });

        const jsonString = response.text;
        const slidesData = JSON.parse(jsonString);

        if (!Array.isArray(slidesData)) {
            throw new Error("API did not return a valid array of slides.");
        }
        
        return slidesData;

    } catch (error) {
        console.error("Error generating slides:", error);
        throw new Error("Failed to generate slide content. Please check your script or try again.");
    }
};

export const generateImageForSlide = async (visualSuggestion: string): Promise<string | null> => {
    const imagePrompt = visualSuggestion.replace(/^(IMAGE:|ILLUSTRATION:)\s*/, '');
    if (!imagePrompt || imagePrompt === visualSuggestion) {
        return null;
    }
    
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [{ text: `Generate a high-quality, visually stunning image for a presentation slide with a 16:9 aspect ratio. The style should be modern, professional, and cinematic. The image must be: ${imagePrompt}` }],
            },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });
        
        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
              const base64ImageBytes: string = part.inlineData.data;
              return `data:image/png;base64,${base64ImageBytes}`;
            }
        }
        return null;
    } catch (error: any) {
        console.error("Error generating image:", error);
        const errorMessage = error.toString().toLowerCase();
        if (errorMessage.includes('429') || errorMessage.includes('quota')) {
            throw new Error("Rate limit exceeded. Please check your API plan or try again later. You can also increase the delay between image requests in the dashboard.");
        }
        throw new Error("An unexpected error occurred while generating the image.");
    }
};