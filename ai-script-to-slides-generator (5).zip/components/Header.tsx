
import React from 'react';
import { SparklesIcon, SettingsIcon } from './icons';

interface HeaderProps {
  onOpenSettings: () => void;
}

const Header: React.FC<HeaderProps> = ({ onOpenSettings }) => {
  return (
    <header className="py-4 px-8 bg-black/50 backdrop-blur-sm sticky top-0 z-20 border-b border-gray-800">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center">
             <SparklesIcon className="w-6 h-6 text-[#00FF99]" />
          </div>
          <h1 className="text-xl font-bold text-white tracking-wider">
            AI SlideDeck
          </h1>
        </div>
        <div>
          <button 
            onClick={onOpenSettings} 
            className="p-2 rounded-full text-gray-400 hover:bg-gray-800 hover:text-white transition-colors"
            aria-label="Open Settings"
          >
            <SettingsIcon className="w-6 h-6" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
