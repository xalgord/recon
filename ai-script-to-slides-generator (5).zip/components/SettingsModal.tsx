
import React, { useState, useEffect } from 'react';
import { XIcon } from './icons';
import { Theme, AppSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSave: (settings: AppSettings) => void;
  themes: Theme[];
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, settings, onSave, themes }) => {
  const [localSettings, setLocalSettings] = useState<AppSettings>(settings);

  useEffect(() => {
    setLocalSettings(settings);
  }, [settings, isOpen]);

  if (!isOpen) {
    return null;
  }
  
  const handleSave = () => {
    onSave(localSettings);
    onClose();
  };

  const handleNumSlidesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value, 10);
    setLocalSettings(prev => ({ ...prev, defaultNumSlides: value > 0 ? value : 1 }));
  };
  
  const handleDelayChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    setLocalSettings(prev => ({ ...prev, defaultRateLimitDelay: value >= 0 ? value : 0 }));
  };

  return (
    <div 
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 flex items-center justify-center"
      onClick={onClose}
    >
      <div 
        className="bg-gray-900 border border-gray-700 rounded-xl shadow-2xl w-full max-w-md m-4"
        onClick={e => e.stopPropagation()}
      >
        <div className="p-6 border-b border-gray-700 flex justify-between items-center">
          <h2 className="text-xl font-bold text-white">App Settings</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        <div className="p-6 space-y-6">
          <p className="text-sm text-gray-400">Set your default preferences. These will be saved in your browser.</p>
          <div>
            <label htmlFor="defaultTheme" className="block text-sm font-medium text-gray-300 mb-2">
              Default Theme
            </label>
            <select
              id="defaultTheme"
              value={localSettings.defaultThemeName}
              onChange={e => setLocalSettings(prev => ({ ...prev, defaultThemeName: e.target.value }))}
              className="w-full bg-gray-800 border-gray-600 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-[#00FF99] focus:border-[#00FF99] transition duration-200"
            >
              {themes.map(theme => (
                <option key={theme.name} value={theme.name}>{theme.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="defaultNumSlides" className="block text-sm font-medium text-gray-300 mb-2">
              Default Number of Slides
            </label>
            <input
              type="number"
              id="defaultNumSlides"
              value={localSettings.defaultNumSlides}
              onChange={handleNumSlidesChange}
              min="1"
              className="w-full bg-gray-800 border-gray-600 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-[#00FF99] focus:border-[#00FF99] transition duration-200"
            />
          </div>
          <div>
            <label htmlFor="defaultDelay" className="block text-sm font-medium text-gray-300 mb-2">
              Default Delay Between Images (sec)
            </label>
            <input
              type="number"
              id="defaultDelay"
              value={localSettings.defaultRateLimitDelay}
              onChange={handleDelayChange}
              min="0"
              step="0.5"
              className="w-full bg-gray-800 border-gray-600 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-[#00FF99] focus:border-[#00FF99] transition duration-200"
            />
          </div>
        </div>
        <div className="p-4 bg-gray-900/50 border-t border-gray-700 text-right rounded-b-xl">
             <button
                onClick={handleSave}
                className="px-6 py-2 bg-[#00FF99] text-black font-bold rounded-lg hover:bg-opacity-80 transition-colors"
              >
                Save & Close
              </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
