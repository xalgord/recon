
import React, { useState, useCallback, useEffect } from 'react';
import { generateSlidesFromScript, generateImageForSlide } from './services/geminiService';
import { Slide as SlideType, Theme, AppSettings } from './types';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Slide from './components/Slide';
import Loader from './components/Loader';
import ExportControls from './components/ExportControls';
import SettingsModal from './components/SettingsModal';

const THEMES: Theme[] = [
    { 
        name: 'Neon Droid',
        backgroundColor: '#000000',
        accentColor: '#00FF99',
        textColor: '#FFFFFF',
        font: 'Inter, sans-serif',
        description: 'A dark, futuristic theme with neon green accents. Think cyberpunk and high-tech.'
    },
    { 
        name: 'Professional',
        backgroundColor: '#FFFFFF',
        accentColor: '#0A74DA',
        textColor: '#1F2937',
        font: 'Inter, sans-serif',
        description: 'A clean, modern, and corporate theme with a blue accent color. Professional and minimalist.'
    },
    {
        name: 'Sunset',
        backgroundColor: '#1E1B4B', // Indigo-900
        accentColor: '#F97316', // Orange-500
        textColor: '#E0E7FF', // Indigo-100
        font: "'Georgia', serif",
        description: 'A warm and creative theme with a dark indigo background and a vibrant orange accent. Evokes a sense of dusk or sunset.'
    },
    {
        name: 'Noir',
        backgroundColor: '#171717', // Neutral-900
        accentColor: '#FFFFFF',
        textColor: '#A3A3A3', // Neutral-400
        font: "'Times New Roman', serif",
        description: 'A dramatic, high-contrast black and white theme. Suggests mystery, elegance, and a cinematic feel.'
    }
];

const APP_SETTINGS_KEY = 'ai-slide-deck-settings';

const DEFAULT_SETTINGS: AppSettings = {
  defaultThemeName: 'Neon Droid',
  defaultNumSlides: 10,
  defaultRateLimitDelay: 2,
};

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const App: React.FC = () => {
  const [slides, setSlides] = useState<SlideType[]>([]);
  const [script, setScript] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [appSettings, setAppSettings] = useState<AppSettings>(() => {
    try {
        const storedSettings = localStorage.getItem(APP_SETTINGS_KEY);
        return storedSettings ? JSON.parse(storedSettings) : DEFAULT_SETTINGS;
    } catch (error) {
        console.error("Could not load settings from local storage", error);
        return DEFAULT_SETTINGS;
    }
  });

  useEffect(() => {
    try {
        localStorage.setItem(APP_SETTINGS_KEY, JSON.stringify(appSettings));
    } catch (error) {
        console.error("Could not save settings to local storage", error);
    }
  }, [appSettings]);

  const [numSlides, setNumSlides] = useState<number>(appSettings.defaultNumSlides);
  const [rateLimitDelay, setRateLimitDelay] = useState<number>(appSettings.defaultRateLimitDelay);
  const [themes] = useState<Theme[]>(THEMES);
  const [selectedTheme, setSelectedTheme] = useState<Theme>(() => themes.find(t => t.name === appSettings.defaultThemeName) || themes[0]);

  // Sync dashboard state if settings change from the modal
  useEffect(() => {
    setNumSlides(appSettings.defaultNumSlides);
    setRateLimitDelay(appSettings.defaultRateLimitDelay);
    setSelectedTheme(themes.find(t => t.name === appSettings.defaultThemeName) || themes[0]);
  }, [appSettings, themes]);

  const handleGenerateSlides = useCallback(async () => {
    if (!script || numSlides <= 0) {
      setError('Please provide a script and a valid number of slides.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setSlides([]);
    
    try {
      setLoadingMessage('Crafting slide content...');
      const slideContents = await generateSlidesFromScript(script, numSlides, selectedTheme.description);

      const initialSlides: SlideType[] = slideContents.map((content, index) => ({
        ...content,
        id: `slide-${index}-${Date.now()}`,
        imageUrl: null,
        backgroundColor: selectedTheme.backgroundColor,
        font: selectedTheme.font,
        accentColor: selectedTheme.accentColor,
      }));
      setSlides(initialSlides);

      setLoadingMessage('Generating stunning visuals...');
      
      const slidesToUpdate = [...initialSlides];
      let imageGenerationFailed = false;

      for (let i = 0; i < slidesToUpdate.length; i++) {
        const slide = slidesToUpdate[i];
        if (slide.visualSuggestion.startsWith('IMAGE:') || slide.visualSuggestion.startsWith('ILLUSTRATION:')) {
            
            const MAX_RETRIES = 3;
            let attempt = 0;
            let success = false;

            while (attempt < MAX_RETRIES && !success) {
                try {
                    setLoadingMessage(`Generating visual for slide ${i + 1}... (Attempt ${attempt + 1})`);
                    const imageUrl = await generateImageForSlide(slide.visualSuggestion);
                    
                    slidesToUpdate[i].imageUrl = imageUrl;
                    setSlides([...slidesToUpdate]);
                    success = true;

                } catch (imageError) {
                    attempt++;
                    const isRateLimitError = imageError instanceof Error && (imageError.message.toLowerCase().includes('rate limit') || imageError.message.toLowerCase().includes('quota'));
                    
                    if (isRateLimitError && attempt < MAX_RETRIES) {
                        const backoffTime = 5000 * Math.pow(2, attempt - 1); // 5s, 10s, 20s
                        setLoadingMessage(`Rate limit hit. Retrying in ${backoffTime / 1000}s...`);
                        await sleep(backoffTime);
                    } else {
                        const finalErrorMsg = imageError instanceof Error ? imageError.message : 'An unknown error occurred during image generation.';
                        console.error(`Failed to generate image for slide ${i + 1} after ${attempt} attempts:`, imageError);
                        setError(finalErrorMsg);
                        imageGenerationFailed = true;
                        break; // Exit while loop
                    }
                }
            }
            if (imageGenerationFailed) {
                break; // Exit for loop if an image failed permanently
            }
        }
        
        if (i < slidesToUpdate.length - 1 && rateLimitDelay > 0) {
            await sleep(rateLimitDelay * 1000);
        }
      }

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [script, numSlides, selectedTheme, rateLimitDelay]);

  const handleSlideUpdate = (index: number, field: 'title' | 'content', value: string) => {
    setSlides(prevSlides => {
      const newSlides = [...prevSlides];
      if (newSlides[index]) {
        newSlides[index][field] = value;
      }
      return newSlides;
    });
  };

  return (
    <div className="bg-gray-900 min-h-screen text-white">
      {isLoading && <Loader message={loadingMessage} />}
      <Header onOpenSettings={() => setIsSettingsOpen(true)} />
      <SettingsModal 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={appSettings}
        onSave={setAppSettings}
        themes={themes}
      />
      <main>
        <Dashboard
          script={script}
          setScript={setScript}
          numSlides={numSlides}
          setNumSlides={setNumSlides}
          rateLimitDelay={rateLimitDelay}
          setRateLimitDelay={setRateLimitDelay}
          onSubmit={handleGenerateSlides}
          isLoading={isLoading}
          themes={themes}
          selectedTheme={selectedTheme}
          onSelectTheme={setSelectedTheme}
        />
        {error && (
          <div className="container mx-auto px-4 text-center my-4">
            <p className="bg-red-900/50 text-red-300 p-3 rounded-lg border border-red-700">{error}</p>
          </div>
        )}
        {slides.length > 0 && (
          <div className="container mx-auto px-4 pb-16 space-y-12">
            <div className='text-center space-y-4'>
                <h2 className="text-3xl font-bold text-white">Your Generated Slides</h2>
                <ExportControls themeName={selectedTheme.name} />
            </div>
            {slides.map((slide, index) => (
              <Slide
                key={slide.id}
                slide={slide}
                index={index}
                onUpdate={handleSlideUpdate}
                textColor={selectedTheme.textColor}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
