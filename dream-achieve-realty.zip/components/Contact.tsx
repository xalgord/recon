import React, { useState } from 'react';

// New, consistent icons
const MapPinIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
    </svg>
);

const PhoneIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
    </svg>
);

const MailIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
    </svg>
);


const SocialIcon: React.FC<{ href: string; children: React.ReactNode }> = ({ href, children }) => (
    <a href={href} target="_blank" rel="noopener noreferrer" className="text-slate-300 hover:text-brand-yellow transition-colors duration-300">
        {children}
    </a>
);


const Contact: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      setStatus('error');
      setTimeout(() => { if (status === 'error') setStatus('idle'); }, 3000);
      return;
    }
    setStatus('submitting');
    await new Promise(resolve => setTimeout(resolve, 1500));
    console.log('Form data submitted:', formData);
    setStatus('success');
    setFormData({ name: '', email: '', subject: '', message: '' });
    setTimeout(() => setStatus('idle'), 5000);
  };

  return (
    <section id="contact" className="py-24 bg-brand-gray">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-brand-blue-dark font-serif">Get In Touch</h2>
          <p className="mt-4 text-lg text-slate-500 max-w-2xl mx-auto">Have a question or want to schedule a viewing? We're here to help.</p>
        </div>
        <div className="max-w-6xl mx-auto bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2">
                <div className="bg-brand-blue-dark text-white p-8 md:p-12 flex flex-col justify-center">
                    <h3 className="text-3xl font-bold mb-4 text-brand-yellow font-serif">Contact Information</h3>
                    <p className="text-slate-300 mb-8 leading-relaxed">
                        Fill up the form and our team will get back to you within 24 hours. Alternatively, you can reach us through the channels below.
                    </p>
                    <ul className="space-y-6">
                        <li className="flex items-start">
                            <MapPinIcon className="w-7 h-7 flex-shrink-0 mt-1 mr-4 text-brand-yellow" />
                            <div>
                                <p className="font-semibold text-lg">Our Office</p>
                                <p className="text-slate-300">123 Realty Rd,<br />Dreamville, USA 12345</p>
                            </div>
                        </li>
                        <li className="flex items-start">
                            <PhoneIcon className="w-7 h-7 flex-shrink-0 mt-1 mr-4 text-brand-yellow" />
                            <div>
                                <p className="font-semibold text-lg">Phone</p>
                                <a href="tel:1234567890" className="text-slate-300 hover:text-white transition-colors">(123) 456-7890</a>
                            </div>
                        </li>
                        <li className="flex items-start">
                            <MailIcon className="w-7 h-7 flex-shrink-0 mt-1 mr-4 text-brand-yellow" />
                            <div>
                                <p className="font-semibold text-lg">Email</p>
                                <a href="mailto:contact@dar.com" className="text-slate-300 hover:text-white transition-colors">contact@dar.com</a>
                            </div>
                        </li>
                    </ul>
                    <div className="mt-10 pt-8 border-t border-blue-900/50">
                         <h4 className="font-semibold text-lg mb-4 text-white">Follow Us</h4>
                         <div className="flex space-x-4">
                            <SocialIcon href="#">
                                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" /></svg>
                            </SocialIcon>
                            <SocialIcon href="#">
                                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.71v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" /></svg>
                            </SocialIcon>
                            <SocialIcon href="#">
                                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.024.06 1.378.06 3.808s-.012 2.784-.06 3.808c-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.024.048-1.378.06-3.808.06s-2.784-.013-3.808-.06c-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.048-1.024-.06-1.378-.06-3.808s.012-2.784.06-3.808c.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 016.345 2.525c.636-.247 1.363-.416 2.427-.465C9.793 2.013 10.148 2 12.315 2zM12 8.118c-2.136 0-3.868 1.733-3.868 3.868s1.732 3.868 3.868 3.868 3.868-1.732 3.868-3.868S14.136 8.118 12 8.118zM12 14.16a2.16 2.16 0 110-4.32 2.16 2.16 0 010 4.32zm4.784-7.41a1.282 1.282 0 01.963.963c.21.57.247 1.105.258 2.112.01.97.01 1.266 0 2.236s-.008.97-.01 1.266-.048.542-.258 2.112a1.283 1.283 0 01-.963.963c-.57.21-1.105.247-2.112.258-.97.01-1.266.01-2.236 0s-.97-.008-1.266-.01-1.542-.048-2.112-.258a1.283 1.283 0 01-.963-.963c-.21-.57-.247-1.105-.258-2.112-.01-.97-.01-1.266 0-2.236s.008-.97.01-1.266.048-.542.258-2.112a1.282 1.282 0 01.963-.963c.57-.21 1.105.247 2.112-.258.97-.01 1.266-.01 2.236 0z" clipRule="evenodd" /></svg>
                            </SocialIcon>
                         </div>
                    </div>
                </div>

                <div className="p-8 md:p-12">
                    {status === 'success' ? (
                         <div className="flex flex-col justify-center items-center text-center h-full">
                            <h3 className="text-2xl font-bold text-green-600 mb-2 font-serif">Message Sent!</h3>
                            <p className="text-slate-600">Thank you for contacting us. We'll be in touch shortly.</p>
                        </div>
                    ) : (
                        <form onSubmit={handleSubmit} noValidate className="h-full flex flex-col">
                            <div className="space-y-6 flex-grow">
                                <div>
                                    <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                                    <input type="text" name="name" id="name" required value={formData.name} onChange={handleChange} className="w-full px-4 py-3 bg-slate-100 rounded-lg border-transparent focus:ring-2 focus:ring-brand-yellow focus:border-brand-yellow outline-none transition" placeholder="John Doe" />
                                </div>
                                <div>
                                    <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
                                    <input type="email" name="email" id="email" required value={formData.email} onChange={handleChange} className="w-full px-4 py-3 bg-slate-100 rounded-lg border-transparent focus:ring-2 focus:ring-brand-yellow focus:border-brand-yellow outline-none transition" placeholder="you@example.com" />
                                </div>
                                <div>
                                     <label htmlFor="subject" className="block text-sm font-medium text-slate-700 mb-1">Subject</label>
                                    <input type="text" name="subject" id="subject" required value={formData.subject} onChange={handleChange} className="w-full px-4 py-3 bg-slate-100 rounded-lg border-transparent focus:ring-2 focus:ring-brand-yellow focus:border-brand-yellow outline-none transition" placeholder="Question about a property" />
                                </div>
                                 <div>
                                     <label htmlFor="message" className="block text-sm font-medium text-slate-700 mb-1">Message</label>
                                    <textarea name="message" id="message" rows={5} required value={formData.message} onChange={handleChange} className="w-full px-4 py-3 bg-slate-100 rounded-lg border-transparent focus:ring-2 focus:ring-brand-yellow focus:border-brand-yellow outline-none transition resize-none" placeholder="I'd like to know more about..."></textarea>
                                </div>
                            </div>
                            {status === 'error' && <p className="text-red-500 text-sm mt-4 text-center">Please fill out all fields before submitting.</p>}
                             <div className="mt-8 text-left">
                                <button type="submit" disabled={status === 'submitting'} className="w-full md:w-auto inline-block px-12 py-4 bg-brand-blue text-white rounded-lg font-bold text-base hover:bg-brand-blue-dark transition-all duration-300 shadow-md hover:shadow-lg transform hover:-translate-y-0.5 disabled:bg-slate-400 disabled:cursor-not-allowed disabled:transform-none">
                                    {status === 'submitting' ? 'Sending...' : 'Send Message'}
                                </button>
                            </div>
                        </form>
                    )}
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;