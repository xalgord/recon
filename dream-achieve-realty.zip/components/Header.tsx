import React, { useState } from 'react';
import { Logo, NAV_LINKS } from '../constants';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white/90 backdrop-blur-lg sticky top-0 z-50 shadow-sm border-b border-gray-100">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-24">
          <a href="#" aria-label="Home">
            <Logo />
          </a>
          <nav className="hidden md:flex items-center space-x-10">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="font-medium text-slate-600 hover:text-brand-blue-dark transition-colors duration-300 relative group"
              >
                <span>{link.label}</span>
                <span className="absolute bottom-0 left-0 w-full h-0.5 bg-brand-yellow scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300 ease-out"></span>
              </a>
            ))}
          </nav>
          <div className="hidden md:block">
             <a href="#contact" className="px-6 py-3 bg-brand-blue text-white rounded-lg font-bold text-sm hover:bg-brand-blue-dark transition-all duration-300 shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
                Get In Touch
            </a>
          </div>
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-slate-700 hover:text-brand-blue-dark focus:outline-none"
              aria-label="Toggle menu"
            >
              <svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16m-7 6h7"} />
              </svg>
            </button>
          </div>
        </div>
      </div>
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-slate-200">
          <nav className="flex flex-col items-center space-y-6 py-6">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setIsMenuOpen(false)}
                className="text-slate-600 hover:text-brand-blue-dark transition-colors duration-300 font-medium text-lg"
              >
                {link.label}
              </a>
            ))}
             <a href="#contact" onClick={() => setIsMenuOpen(false)} className="w-11/12 text-center px-5 py-3 bg-brand-blue text-white rounded-lg font-semibold text-base hover:bg-brand-blue-dark transition-all duration-300 shadow-md">
                Get In Touch
            </a>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;