import React from 'react';
import type { Property } from '../types';

interface PropertyCardProps {
  property: Property;
}

const BedIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2 4v16h20V4H2z" />
    <path d="M2 9h20" />
    <path d="M10 4v5" />
  </svg>
);

const BathIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 6l2 2 2-2" />
    <path d="M12 22V8" />
    <path d="M5 22h14" />
    <path d="M5 18h14" />
  </svg>
);

const SqftIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 8V2l-6 6" />
    <path d="M3 16v6h6l-6-6" />
    <path d="M3 8V2h6l-6 6" />
    <path d="M21 16v6h-6l6-6" />
  </svg>
);


const PropertyCard: React.FC<PropertyCardProps> = ({ property }) => {
  const displayPrice = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    notation: 'compact',
    compactDisplay: 'short',
    minimumFractionDigits: 0,
    maximumFractionDigits: 1
  }).format(property.price * (property.type === 'For Sale' ? 100 : 1));

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300 group border border-gray-100 hover:shadow-2xl">
      <div className="relative overflow-hidden">
        <img src={property.image} alt={property.address} className="w-full h-56 object-cover transform group-hover:scale-110 transition-transform duration-500" />
        <div className={`absolute top-4 left-4 px-3 py-1 text-sm font-semibold text-white rounded-md ${property.type === 'For Sale' ? 'bg-brand-blue' : 'bg-green-600'}`}>
          {property.type}
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
        <div className="absolute bottom-0 left-0 p-4">
             <h3 className="font-bold text-lg text-white ">{property.address}</h3>
             <p className="text-sm text-gray-300">{property.city}</p>
        </div>
      </div>
      <div className="p-6">
        <div className="flex justify-between items-center">
            <p className="font-extrabold text-2xl text-brand-blue-dark font-serif">{displayPrice}{property.type === 'For Rent' && <span className="text-base font-medium text-slate-500">/mo</span>}</p>
        </div>
        
        <div className="mt-4 pt-4 border-t border-slate-100 flex justify-around text-slate-600">
          <div className="text-center">
            <span className="font-bold text-lg text-brand-blue-dark">{property.beds}</span>
            <p className="text-xs text-slate-500">Beds</p>
          </div>
          <div className="text-center">
            <span className="font-bold text-lg text-brand-blue-dark">{property.baths}</span>
            <p className="text-xs text-slate-500">Baths</p>
          </div>
          <div className="text-center">
            <span className="font-bold text-lg text-brand-blue-dark">{property.sqft.toLocaleString('en-IN')}</span>
            <p className="text-xs text-slate-500">sqft</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;