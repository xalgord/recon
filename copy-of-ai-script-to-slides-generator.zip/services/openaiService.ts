import { Slide, SlideLayout } from '../types';

const slideLayouts: SlideLayout[] = [
    'TITLE_ONLY', 
    'TITLE_AND_CONTENT', 
    'IMAGE_LEFT_TEXT_RIGHT', 
    'IMAGE_RIGHT_TEXT_LEFT',
    'FULL_BLEED_IMAGE',
    'BLANK'
];

const slideGenerationPrompt = (script: string, numSlides: number, themeDescription: string) => `
    You are an expert presentation designer. Your task is to transform the following script into a visually engaging presentation with a specific theme.

    **Theme:** ${themeDescription}

    **Script:**
    ---
    ${script}
    ---

    **Instructions:**
    1.  Create exactly ${numSlides} slides.
    2.  Divide the script logically into ${numSlides} distinct sections for each slide.
    3.  For each slide, create a short, impactful title (max 10 words) and concise content (bullet points or a short paragraph, max 50 words). Summarize the script content for a presentation format.
    4.  For each slide, choose the best layout from the available options: ${slideLayouts.join(', ')}.
    5.  For each slide, provide a visual suggestion that perfectly matches the presentation's theme. It MUST be one of the following types:
        *   **IMAGE:** A detailed description for an AI image generator (e.g., "IMAGE: A minimalist black and white photo of a mountain peak.").
        *   **ILLUSTRATION:** A detailed description for an AI illustration (e.g., "ILLUSTRATION: A flat design style illustration of a person watering a growing plant.").
        *   **GRAPHIC:** A concept for a simple graphic (e.g., "GRAPHIC: An upward trending arrow.").
        *   **LOGO:** A suggestion for a logo (e.g., "LOGO: The Google logo.").
        *   **NONE:** If no visual is suitable for the slide.
    6.  The final output must be a JSON object containing a single key "slides" which is an array of slide objects. Each object must have keys: "title", "content", "layout", and "visualSuggestion".
`;


export const generateSlidesFromScript = async (apiKey: string, script: string, numSlides: number, themeDescription: string): Promise<Omit<Slide, 'id' | 'imageUrl' | 'backgroundColor' | 'font' | 'accentColor'>[]> => {
    if (!apiKey) throw new Error("API Key is missing.");

    const body = {
        model: "gpt-4o",
        messages: [{ role: "user", content: slideGenerationPrompt(script, numSlides, themeDescription) }],
        response_format: { type: "json_object" },
    };

    try {
        const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`,
            },
            body: JSON.stringify(body),
        });

        if (!response.ok) {
            const errorData = await response.json();
            console.error("OpenAI API error:", errorData);
            throw new Error(`OpenAI API Error: ${errorData.error?.message || response.statusText}`);
        }

        const data = await response.json();
        const jsonString = data.choices[0].message.content;
        const parsed = JSON.parse(jsonString);

        if (!Array.isArray(parsed.slides)) {
            throw new Error("API did not return a valid array of slides.");
        }
        
        return parsed.slides;

    } catch (error) {
        console.error("Error generating slides with OpenAI:", error);
        throw new Error("Failed to generate slide content. Please check your OpenAI API key and script.");
    }
};

export const generateImageForSlide = async (apiKey: string, visualSuggestion: string): Promise<string | null> => {
    if (!apiKey) throw new Error("API Key is missing.");
    
    const imagePrompt = visualSuggestion.replace(/^(IMAGE:|ILLUSTRATION:)\s*/, '');
    if (!imagePrompt || imagePrompt === visualSuggestion) return null;

    const body = {
        model: "dall-e-3",
        prompt: `A high-quality, visually stunning image for a presentation slide with a 16:9 aspect ratio. The style should be modern, professional, and cinematic. The image must be: ${imagePrompt}`,
        n: 1,
        size: "1792x1024", // DALL-E 3's landscape aspect ratio
        response_format: "b64_json",
    };

    try {
        const response = await fetch("https://api.openai.com/v1/images/generations", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`,
            },
            body: JSON.stringify(body),
        });

        if (!response.ok) {
            const errorData = await response.json();
            console.error("OpenAI Image API error:", errorData);
            if (response.status === 429) {
                throw new Error("Rate limit exceeded with the current OpenAI API key. Please check your API plan.");
            }
            throw new Error(`OpenAI Image API Error: ${errorData.error?.message || response.statusText}`);
        }
        
        const data = await response.json();
        const base64Image = data.data[0].b64_json;
        return `data:image/png;base64,${base64Image}`;

    } catch (error) {
        console.error("Error generating image with OpenAI:", error);
        if (error instanceof Error) {
            throw error;
        }
        throw new Error("An unexpected error occurred while generating the image with DALL-E.");
    }
};