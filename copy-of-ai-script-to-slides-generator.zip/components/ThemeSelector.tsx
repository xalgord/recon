import React from 'react';
import { Theme } from '../types';

interface ThemeSelectorProps {
  themes: Theme[];
  selectedTheme: Theme;
  onSelectTheme: (theme: Theme) => void;
}

const ThemeSelector: React.FC<ThemeSelectorProps> = ({ themes, selectedTheme, onSelectTheme }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {themes.map((theme) => (
        <button
          key={theme.name}
          onClick={() => onSelectTheme(theme)}
          className={`relative p-3 rounded-lg border-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-[#00FF99] ${
            selectedTheme.name === theme.name ? 'border-[#00FF99]' : 'border-gray-600 hover:border-gray-500'
          }`}
          style={{ backgroundColor: theme.backgroundColor }}
        >
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold" style={{ color: theme.textColor }}>
              {theme.name}
            </span>
            <div className="flex items-center space-x-1">
                <div className="w-4 h-4 rounded-full" style={{ backgroundColor: theme.accentColor }}></div>
                <div className="w-4 h-4 rounded-full" style={{ backgroundColor: theme.textColor }}></div>
            </div>
          </div>
        </button>
      ))}
    </div>
  );
};

export default ThemeSelector;
